// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"node_modules/regenerator-runtime/runtime.js":[function(require,module,exports) {
var define;
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
  typeof module === "object" ? module.exports : {}
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}

},{}],"src/vehicle.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Vehicle = /*#__PURE__*/function () {
  //FIX IS ENTERING BUG!!!!
  function Vehicle(game, isAnimating) {
    var _this = this;

    _classCallCheck(this, Vehicle);

    this.game = game;
    this.isAnimating = isAnimating;
    this.loadRewardFunction().then(function () {
      _this.loadedRFunc = true;
    });
    this.img = document.getElementById("img_car_side");
    this.scale_factor = 10 / 10;
    this.max_speed = {
      x: 0.1,
      y: 0.1
    };
    this.speed = {
      x: 0,
      y: 0
    };
    this.position = game.spawnPoint;
    this.curStatePrevCords = game.spawnPoint;
    this.goal = this.position;
    this.cellSize = game.gameWidth / 10;
    this.gameWidth = game.gameWidth;
    this.gameHeight = game.gameHeight;
    this.i = 0;
    this.lastCol = {
      x: -1,
      y: -1
    };
    this.just_spawned = true;
    this.isDone = false;
    this.reachedGoal = false;
    this.prevGoalLCol = [null, null];
    this.updatedScore = false;
    this.lastAction = null;
    this.sideSizeX = this.scale_factor * this.cellSize;
    this.sideSizeY = this.scale_factor * this.cellSize * (4 / 5);
    this.backSizeX = this.scale_factor * this.cellSize;
    this.backSizeY = this.scale_factor * this.cellSize;
    this.size_x = this.sideSizeX;
    this.size_y = this.sideSizeY;
  }

  _createClass(Vehicle, [{
    key: "loadRewardFunction",
    value: function () {
      var _loadRewardFunction = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var rjson, i, row, j, stateRs, r;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return fetch('https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/boards/' + String(this.game.boardName) + '_rewards_function.json');

              case 2:
                _context.next = 4;
                return _context.sent.json();

              case 4:
                rjson = _context.sent;
                //console.log(json)
                // console.log(rjson);
                this.rFunc = [];

                for (i in rjson) {
                  row = [];

                  for (j in rjson[i]) {
                    stateRs = [];

                    for (r in rjson[i][j]) {
                      stateRs.push(rjson[i][j][r]);
                    }

                    row.push(stateRs);
                  }

                  this.rFunc.push(row); // this.keys.push(i);
                }

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function loadRewardFunction() {
        return _loadRewardFunction.apply(this, arguments);
      }

      return loadRewardFunction;
    }()
  }, {
    key: "inBlocking",
    value: function inBlocking(cords) {
      for (var i = 0; i < this.game.blockingCords.length; i++) {
        if (cords.x === this.game.blockingCords[i].x && cords.y === this.game.blockingCords[i].y) {
          return true;
        }
      }

      return false;
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    } //
    // calcCellPos() {
    //   this.x2draw =
    //     this.cellSize * this.position.x +
    //     (this.position.x + this.cellSize) / 2 -
    //     this.size_x / 2;
    //   this.y2draw =
    //     this.cellSize * this.position.y +
    //     (this.position.y + this.cellSize) / 2 -
    //     this.size_y / 2;
    // }

  }, {
    key: "isdone",
    value: function isdone() {
      var ib = this.find_is_blocking();

      if (ib || this.game.isLeaving === true) {
        this.isDone = true;
        this.game.trajHandler.incompleteCords.push(this.lastCol);
        this.game.trajHandler.incompleteActions.push(this.lastAction); // console.log(this.lastAction);

        return true;
      }

      if (this.position.x - this.goal.x < 0.1 && this.position.y - this.goal.y < 0.1 && this.position.x - this.goal.x >= -0.01 && this.position.y - this.goal.y >= -0.01 || this.goal.x - this.position.x === 0 && this.goal.y - this.position.y === 0) {
        this.position = this.goal;
        this.isDone = true;
        return true;
      } // if (this.i < 10) {
      //   console.log(this.goal);
      //   console.log(this.position);
      //   this.i += 1;
      // }


      this.isDone = false;
      return false;
    }
  }, {
    key: "moveLeft",
    value: function moveLeft() {
      // console.log(this.isdone())
      // this.game.isLeaving = false;
      if (this.isdone() && !this.game.reached_terminal) {
        this.lastAction = "left";
        var posGoal = {
          x: this.position.x - 1,
          y: this.position.y
        };
        this.game.find_is_leaving_ow(posGoal); //log player activity during each game

        if (this.game.isLeaving) {
          this.game.triedLeaving = true;
        } else if (this.position.x - 1 < 0) {
          this.game.hitEdge = true;
        } else if (this.inBlocking(posGoal)) {
          this.game.hitHouse = true;
        }

        if (!this.game.isLeaving && this.position.x - 1 >= 0 && !this.inBlocking(posGoal)) {
          this.reachedGoal = false;
          this.speed.x = -this.max_speed.x;
          this.goal = {
            x: this.position.x - 1,
            y: this.position.y
          };
        } else {
          this.goal = {
            x: this.position.x,
            y: this.position.y
          };
          this.game.trajHandler.incompleteCords.push(this.goal);
          this.game.trajHandler.incompleteActions.push("left");
          this.incAction = true;
          this.lastAct = {
            x: -1,
            y: 0
          };
        }

        this.img = document.getElementById("img_car_side_f");
        this.size_x = this.sideSizeX;
        this.size_y = this.sideSizeY;
      }
    }
  }, {
    key: "moveRight",
    value: function moveRight() {
      // this.game.isLeaving = false;
      if (this.isdone() && !this.game.reached_terminal) {
        this.lastAction = "right";
        var posGoal = {
          x: this.position.x + 1,
          y: this.position.y
        };
        this.game.find_is_leaving_ow(posGoal); //log player activity during each game

        if (this.game.isLeaving) {
          this.game.triedLeaving = true;
        } else if (this.position.x + 1 >= 10) {
          this.game.hitEdge = true;
        } else if (this.inBlocking(posGoal)) {
          this.game.hitHouse = true;
        }

        if (!this.game.isLeaving && this.position.x + 1 < 10 && !this.inBlocking(posGoal)) {
          this.reachedGoal = false;
          this.speed.x = this.max_speed.x;
          this.goal = {
            x: this.position.x + 1,
            y: this.position.y
          };
        } else {
          this.goal = {
            x: this.position.x,
            y: this.position.y
          };
          this.game.trajHandler.incompleteCords.push(this.goal);
          this.game.trajHandler.incompleteActions.push("right");
          this.incAction = true;
          this.lastAct = {
            x: 1,
            y: 0
          };
        }

        this.img = document.getElementById("img_car_side");
        this.size_x = this.sideSizeX;
        this.size_y = this.sideSizeY;
      }
    }
  }, {
    key: "moveUp",
    value: function moveUp() {
      //if we are animating stop car from running into our label
      if (this.isAnimating && this.position.y - 1 < 3) {
        return;
      }

      if (this.isdone() && !this.game.reached_terminal) {
        this.lastAction = "up";
        var posGoal = {
          x: this.position.x,
          y: this.position.y - 1
        };
        this.game.find_is_leaving_ow(posGoal); //log player activity during each game

        if (this.game.isLeaving) {
          this.game.triedLeaving = true;
        } else if (this.position.y - 1 < 0) {
          this.game.hitEdge = true;
        } else if (this.inBlocking(posGoal)) {
          this.game.hitHouse = true;
        }

        if (!this.game.isLeaving && this.position.y - 1 >= 0 && !this.inBlocking(posGoal)) {
          this.reachedGoal = false;
          this.speed.y = -this.max_speed.y;
          this.goal = posGoal;
        } else {
          this.goal = {
            x: this.position.x,
            y: this.position.y
          };
          this.game.trajHandler.incompleteCords.push(this.goal);
          this.game.trajHandler.incompleteActions.push("up");
          this.incAction = true;
          this.lastAct = {
            x: 0,
            y: -1
          };
        }

        this.img = document.getElementById("img_car_back");
        this.size_x = this.backSizeX;
        this.size_y = this.backSizeY;
      }
    }
  }, {
    key: "moveDown",
    value: function moveDown() {
      // this.game.isLeaving = false;
      if (this.isdone() && !this.game.reached_terminal) {
        this.lastAction = "down";
        var posGoal = {
          x: this.position.x,
          y: this.position.y + 1
        };
        this.game.find_is_leaving_ow(posGoal);

        if (this.game.isLeaving) {
          this.game.triedLeaving = true;
        } else if (this.position.y + 1 >= 10) {
          this.game.hitEdge = true;
        } else if (this.inBlocking(posGoal)) {
          this.game.hitHouse = true;
        }

        if (!this.game.isLeaving && this.position.y + 1 < 10 && !this.inBlocking(posGoal)) {
          this.reachedGoal = false;
          this.speed.y = this.max_speed.y;
          this.goal = posGoal; // console.log(this.goal);
        } else {
          this.goal = {
            x: this.position.x,
            y: this.position.y
          };
          this.game.trajHandler.incompleteCords.push(this.goal);
          this.game.trajHandler.incompleteActions.push("down");
          this.incAction = true;
          this.lastAct = {
            x: 0,
            y: 1
          };
        }

        this.img = document.getElementById("img_car_front");
        this.size_x = this.backSizeX;
        this.size_y = this.backSizeY;
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      if (this.isdone()) {
        this.speed.x = 0;
        this.speed.y = 0;
      }
    } // clearCols() {
    //   this.game.gameObjects.forEach(
    //     (object) => (object.lastCol = { x: -1, y: -1 })
    //   );
    // }
    // find_is_leaving_ow() {
    //   this.isLeaving = false;
    //   //check if the car is trying to leave a oneway area
    //   if (!this.is_in_ow) return false;
    //   let is_blocked = true;
    //   this.isLeaving = true;
    //   for (var i = 0; i < this.game.ow_cords.length; i++) {
    //     // use array[i] here
    //     let ow_pos = this.game.ow_cords[i];
    //     if (ow_pos.x === this.goal.x && ow_pos.y === this.goal.y) {
    //       is_blocked = false;
    //       this.isLeaving = false;
    //     }
    //   }
    //   return is_blocked;
    // }

  }, {
    key: "getDir",
    value: function getDir(vec) {
      if (vec.x > 0) {
        return "right";
      } else if (vec.x < 0) {
        return "left";
      } else if (vec.y > 0) {
        return "down";
      } else if (vec.y < 0) {
        return "up";
      } else {
        return "same";
      }
    }
  }, {
    key: "find_is_blocking",
    value: function find_is_blocking() {
      //check if the car is blocked
      var is_blocked = false;

      for (var i = 0; i < this.game.blocking_cords.length; i++) {
        // use array[i] here
        var blocking_pos = this.game.blocking_cords[i];

        if (blocking_pos.x === this.goal.x && blocking_pos.y === this.goal.y) {
          is_blocked = true;
        }
      }

      return is_blocked;
    }
  }, {
    key: "findActionIndex",
    value: function findActionIndex(a) {
      //actions = [[-1,0],[1,0],[0,-1],[0,1]]
      var actions = [{
        x: -1,
        y: 0
      }, {
        x: 1,
        y: 0
      }, {
        x: 0,
        y: -1
      }, {
        x: 0,
        y: 1
      }];

      for (var i = 0; i < actions.length; i++) {
        if (actions[i].y === a.x && actions[i].x === a.y) {
          return i;
        }
      }

      return false;
    }
  }, {
    key: "updateScore",
    value: function updateScore(a) {
      if (!this.just_spawned) {
        // console.log("updating");
        var aI = this.findActionIndex(a);
        this.updatedScore = true;

        if (this.loadedRFunc) {
          var ds = this.rFunc[this.curStatePrevCords.y][this.curStatePrevCords.x][aI];
          this.game.score += ds;

          if (!this.game.reached_terminal) {
            if (!this.game.is_in_ow(this.curStatePrevCords)) {
              this.game.gasScore -= 1;
            } else {
              this.game.gasScore -= 2;
            }
          } else {
            if (ds === 50) {
              this.game.hitFlag = true;
            } else if (ds === -50) {
              this.game.hitPerson = true;
            }
          }

          this.game.pScore = this.game.score - this.game.gasScore;
        } // console.log(
        //   this.rFunc[this.curStatePrevCords.y][this.curStatePrevCords.x][aI]
        // );


        var ns = {
          x: this.curStatePrevCords.x + a.x,
          y: this.curStatePrevCords.y + a.y
        };

        if (ns.x >= 0 && ns.x < 10 && ns.y >= 0 && ns.y < 10) {
          if (!this.inBlocking(ns) && !(this.game.is_in_ow(this.curStatePrevCords) && !this.game.is_in_ow(ns))) this.curStatePrevCords = ns;
        }
      }
    }
  }, {
    key: "update",
    value: function update(deltaTime) {
      this.game.find_is_leaving_ow(this.goal);
      this.new_pos = {
        x: this.position.x + this.speed.x,
        y: this.position.y + this.speed.y
      };

      if (!this.isdone()) {
        this.position = this.new_pos;
      }

      if (this.isdone()) {
        // if (!this.game.is_in_ow()) {
        if (this.goal.x !== this.lastCol.x || this.goal.y !== this.lastCol.y || this.incAction) {
          if (!this.isAnimating) window.timestep += 1;

          if (this.incAction) {
            //this.lastAct
            this.updateScore({
              x: this.lastAct.x,
              y: this.lastAct.y
            });
          } else {
            this.updateScore({
              x: this.goal.x - this.lastCol.x,
              y: this.goal.y - this.lastCol.y
            });
          }

          this.just_spawned = false;
          this.incAction = false;
        }

        if (this.game.reached_terminal) {
          this.lastCol = this.goal;
          this.reachedGoal = true;
          this.stop();
          return;
        }

        if (!this.game.isLeaving) this.lastCol = this.goal;
        this.reachedGoal = true;
        this.stop();
      }
    }
  }]);

  return Vehicle;
}();

exports.default = Vehicle;
},{}],"src/collisionDetection.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.detectCollision = detectCollision;

function detectCollision(vehicle, gameObject) {
  if (vehicle.goal.x === gameObject.position.x && vehicle.goal.y === gameObject.position.y && gameObject.lastCol.x != gameObject.position.x && gameObject.lastCol.y != gameObject.position.y) {
    gameObject.lastCol = {
      x: gameObject.position.x,
      y: gameObject.position.y
    };
    return true;
  }

  return false;
}
},{}],"src/house.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var House = /*#__PURE__*/function () {
  function House(game, position) {
    _classCallCheck(this, House);

    this.img = document.getElementById("img_house");
    this.game = game;
    this.position = position;
    this.game.blockingCords.push(this.position);
    this.size_x = 50;
    this.size_y = 50;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    }; // this.markedForDeletion = false;
  }

  _createClass(House, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {// this.game.ball.speed.x = 0;
        // this.game.ball.speed.y = 0;
        // this.markedForDeletion = true;
        // this.game.score -= 1;
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    }
  }]);

  return House;
}();

exports.default = House;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/flag.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Flag = /*#__PURE__*/function () {
  function Flag(game, position) {
    _classCallCheck(this, Flag);

    this.img = document.getElementById("img_flag");
    this.game = game;
    this.position = position;
    this.size_x = 50;
    this.size_y = 50;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    }; // this.markedForDeletion = false;
  }

  _createClass(Flag, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {
        // this.game.ball.speed.x = 0;
        // this.game.ball.speed.y = 0;
        // this.markedForDeletion = true;
        this.game.find_is_leaving_ow(this.position);

        if (!this.game.isLeaving) {
          this.game.reached_terminal = true; // this.game.score += 50;
          // this.game.pScore += 50;

          this.game.vehicle.updatedScore = true;
        }
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    }
  }]);

  return Flag;
}();

exports.default = Flag;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/person.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Person = /*#__PURE__*/function () {
  function Person(game, position) {
    _classCallCheck(this, Person);

    this.img = document.getElementById("img_person");
    this.game = game;
    this.position = position;
    this.size_x = 50;
    this.size_y = 50;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    }; // this.markedForDeletion = false;
  }

  _createClass(Person, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {
        // this.game.ball.speed.x = 0;
        // this.game.ball.speed.y = 0;
        // this.markedForDeletion = true;
        this.game.find_is_leaving_ow(this.position);

        if (!this.game.isLeaving) {
          this.game.reached_terminal = true; // this.game.score -= 50;
          // this.game.pScore -= 50;

          this.game.vehicle.updatedScore = true;
        }
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    }
  }]);

  return Person;
}();

exports.default = Person;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/coin.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Coin = /*#__PURE__*/function () {
  function Coin(game, position) {
    _classCallCheck(this, Coin);

    this.img = document.getElementById("img_coin");
    this.game = game;
    this.position = position;
    this.size_x = 30;
    this.size_y = 30;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    }; // this.markedForDeletion = false;
  }

  _createClass(Coin, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {
        // this.game.ball.speed.y = -this.game.ball.speed.y;
        // this.markedForDeletion = true;
        this.game.find_is_leaving_ow(this.position);

        if (!this.game.isLeaving) {
          // this.game.score += 1;
          // this.game.pScore += 1;
          this.game.collectedCoin = true;
          this.game.vehicle.updatedScore = true;
        }
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      // console.log(this.position);
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    }
  }]);

  return Coin;
}();

exports.default = Coin;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/garbage.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Garbage = /*#__PURE__*/function () {
  function Garbage(game, position) {
    _classCallCheck(this, Garbage);

    this.img = document.getElementById("img_garbage");
    this.game = game;
    this.position = position;
    this.size_x = 50;
    this.size_y = 50;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    }; // this.markedForDeletion = false;
  }

  _createClass(Garbage, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {
        // this.game.ball.speed.x = 0;
        // this.game.ball.speed.y = 0;
        // this.markedForDeletion = true;
        this.game.find_is_leaving_ow(this.position);

        if (!this.game.isLeaving) {
          // this.game.score -= 1;
          // this.game.pScore -= 1;
          this.game.vehicle.updatedScore = true;
        }
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x + this.cellSize / 2 - this.size_x / 2, this.cellSize * this.position.y + this.cellSize / 2 - this.size_y / 2, this.size_x, this.size_y);
    }
  }]);

  return Garbage;
}();

exports.default = Garbage;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/owTile.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _collisionDetection = require("./collisionDetection");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var OWTile = /*#__PURE__*/function () {
  function OWTile(game, position) {
    _classCallCheck(this, OWTile);

    this.img = document.getElementById("img_ow_tile");
    this.blockade = document.getElementById("img_blockade");
    this.game = game;
    this.position = position;
    this.size_x = 80;
    this.size_y = 80;
    this.cellSize = game.gameWidth / 10;
    this.lastCol = {
      x: -1,
      y: -1
    };
    this.isLeaving = false;
    this.leavingGoal = null; // this.markedForDeletion = false;
  } // detectIsLeaving(vehicle) {
  //   if (vehicle.find_is_leaving_ow() && this.isLeaving === false) {
  //     this.isLeaving = true;
  //     this.leavingGoal = vehicle.goal;
  //     this.game.score -= 2;
  //     this.game.gasScore -= 2;
  //     return true;
  //   }
  //   return false;
  //   // if (
  //   //   vehicle.find_is_leaving_ow() &&
  //   //   this.isLeaving === true &&
  //   //   this.leavingGoal !== vehicle.goal
  //   // ) {
  //   //   this.isLeaving = true;
  //   //   return true;
  //   // }
  //   // if (!vehicle.find_is_leaving_ow()) {
  //   //   this.isLeaving = false;
  //   // }
  //   return false;
  // }


  _createClass(OWTile, [{
    key: "update",
    value: function update() {
      if ((0, _collisionDetection.detectCollision)(this.game.vehicle, this)) {
        // this.game.ball.speed.x = 0;
        // this.game.ball.speed.y = 0;
        // this.markedForDeletion = true;
        // console.log("here");
        this.game.is_in_blocking = true; // this.game.score -= 2;
        // this.game.gasScore -= 2;

        this.game.vehicle.updatedScore = true;
      }
    }
  }, {
    key: "isOW",
    value: function isOW(cords) {
      for (var i = 0; i < this.game.ow_cords.length; i++) {
        // use array[i] here
        var ow_pos = this.game.ow_cords[i];

        if (cords.x === ow_pos.x && cords.y === ow_pos.y) {
          return true;
        }
      }

      return false;
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img, this.cellSize * this.position.x, this.cellSize * this.position.y, this.size_x, this.size_y); //check if above tile is a oneway tile

      if (!this.isOW({
        x: this.position.x,
        y: this.position.y - 1
      })) {
        ctx.drawImage(this.blockade, this.cellSize * this.position.x - 7, this.cellSize * this.position.y - 20, 75, 30); // ctx.drawImage(
        //   this.blockade,
        //   this.cellSize * this.position.x + 28,
        //   this.cellSize * this.position.y - 20,
        //   40,
        //   30
        // );
      }

      if (!this.isOW({
        x: this.position.x,
        y: this.position.y + 1
      })) {
        ctx.drawImage(this.blockade, this.cellSize * this.position.x - 7, this.cellSize * this.position.y + this.cellSize, 75, 30); // ctx.drawImage(
        //   this.blockade,
        //   this.cellSize * this.position.x + 30,
        //   this.cellSize * this.position.y + this.cellSize - 25,
        //   40,
        //   30
        // );
      }
    }
  }]);

  return OWTile;
}();

exports.default = OWTile;
},{"./collisionDetection":"src/collisionDetection.js"}],"src/input.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var InputHandler = function InputHandler(vehicle) {
  _classCallCheck(this, InputHandler);

  document.addEventListener("keydown", function (event) {
    switch (event.keyCode) {
      case 37:
        vehicle.moveLeft();
        break;

      case 38:
        vehicle.moveUp();
        break;

      case 39:
        vehicle.moveRight();
        break;

      case 40:
        vehicle.moveDown();
        break;
    }
  });
  document.addEventListener("keyup", function (event) {
    switch (event.keyCode) {
      case 37:
        if (vehicle.speed.x < 0) {
          vehicle.stop();
        }

        break;

      case 38:
        if (vehicle.speed.y < 0) {
          vehicle.stop();
        }

        break;

      case 39:
        if (vehicle.speed.x > 0) {
          vehicle.stop();
        }

        break;

      case 40:
        if (vehicle.speed.y > 0) {
          vehicle.stop();
        }

    }
  });
};

exports.default = InputHandler;
},{}],"src/trajHandler.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// // import screenshot from "desktop-screenshot";
// const fs = require('fs')
// const screenshot = require('screenshot-desktop')
// var {spawn} = require('child_process')
var TrajHandler = /*#__PURE__*/function () {
  function TrajHandler(vehicle, game) {
    var _this = this;

    _classCallCheck(this, TrajHandler);

    this.trajLength = 3;
    this.vehicle = vehicle;
    this.game = game;
    this.loadPassingSpaces().then(function () {
      _this.loadedTrajData = true;
    }); // this.json = require("/assets/trajData/ql_passing_spaces.json");

    this.loadedRFunc = false;
    this.tookScreenShot = false;
    this.loadRewardFunction().then(function () {
      _this.loadedRFunc = true;
    });
    this.i = 0;
    this.prevI = -1;
    this.cordsI = 0;
    this.quadI = 0;
    this.trajp = 0;
    this.cellSize = vehicle.cellSize;
    this.trajCords = [];
    this.actions = []; // this.fillStyles = ["red", "blue", "green", "purple"];

    this.nStyles = 0;
    this.pos2img = {
      left: "img_car_side_f",
      right: "img_car_side",
      up: "img_car_back",
      down: "img_car_front"
    };
    this.pos2dim = {
      left: {
        x: this.vehicle.sideSizeX,
        y: this.vehicle.sideSizeY
      },
      right: {
        x: this.vehicle.sideSizeX,
        y: this.vehicle.sideSizeY
      },
      up: {
        x: this.vehicle.backSizeX,
        y: this.vehicle.backSizeY
      },
      down: {
        x: this.vehicle.backSizeX,
        y: this.vehicle.backSizeY
      }
    };
    this.incompleteCords = [];
    this.incompleteActions = [];
    this.x_img = document.getElementById("img_x");
    this.img_arrow_right = document.getElementById("img_arrow_right");
    this.img_arrow_left = document.getElementById("img_arrow_left");
    this.isPrinted = false;
    this.score = 0;
    this.gasScore = 0;
    this.pScore = 0;
  }

  _createClass(TrajHandler, [{
    key: "loadPassingSpaces",
    value: function () {
      var _loadPassingSpaces = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var i;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return fetch("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/trajData/ql_passing_spaces.json");

              case 2:
                _context.next = 4;
                return _context.sent.json();

              case 4:
                this.json = _context.sent;
                this.keys = [];

                for (i in this.json) {
                  this.keys.push(i);
                } // console.log(this.keys);


              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function loadPassingSpaces() {
        return _loadPassingSpaces.apply(this, arguments);
      }

      return loadPassingSpaces;
    }()
  }, {
    key: "loadRewardFunction",
    value: function () {
      var _loadRewardFunction = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var rjson, i, row, j, stateRs, r;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return fetch('https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/boards/' + String(this.game.boardName) + '_rewards_function.json');

              case 2:
                _context2.next = 4;
                return _context2.sent.json();

              case 4:
                rjson = _context2.sent;
                // console.log(rjson);
                this.rFunc = [];

                for (i in rjson) {
                  row = [];

                  for (j in rjson[i]) {
                    stateRs = [];

                    for (r in rjson[i][j]) {
                      stateRs.push(rjson[i][j][r]);
                    }

                    row.push(stateRs);
                  }

                  this.rFunc.push(row); // this.keys.push(i);
                }

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function loadRewardFunction() {
        return _loadRewardFunction.apply(this, arguments);
      }

      return loadRewardFunction;
    }()
  }, {
    key: "updatePos",
    value: function updatePos(ns) {
      this.vehicle.goal = ns;

      if (!this.game.find_is_leaving_ow(ns) && !this.vehicle.find_is_blocking()) {
        if (ns.x >= 0 && ns.x <= 9 && ns.y >= 0 && ns.y <= 9) {
          this.vehicle.lastCol = ns;
          this.vehicle.position = ns;
        }
      }
    }
  }, {
    key: "findActionIndex",
    value: function findActionIndex(a) {
      //actions = [[-1,0],[1,0],[0,-1],[0,1]]
      var actions = [{
        x: -1,
        y: 0
      }, {
        x: 1,
        y: 0
      }, {
        x: 0,
        y: -1
      }, {
        x: 0,
        y: 1
      }];

      for (var i = 0; i < actions.length; i++) {
        if (actions[i].x === a.x && actions[i].y === a.y) {
          return i;
        }
      }

      return false;
    }
  }, {
    key: "updateScore",
    value: function updateScore(a) {
      if (this.vehicle.isDone) {
        if (!this.game.reached_terminal) {
          var aI = this.findActionIndex({
            x: a[0],
            y: a[1]
          });

          if (this.loadedRFunc) {
            this.score += this.rFunc[this.curStatePrevCords.y][this.curStatePrevCords.x][aI];
            this.prevI = this.i; // console.log(
            //   this.rFunc[this.curStatePrevCords.y][this.curStatePrevCords.x][aI]
            // );

            if (!this.game.is_in_ow(this.curStatePrevCords)) {
              this.gasScore -= 1;
            } else {
              this.gasScore -= 2;
            }

            this.pScore = this.score - this.gasScore;
          } // console.log(a);
          // console.log(this.curStatePrevCords);
          // console.log(
          //   this.rFunc[this.curStatePrevCords.y][this.curStatePrevCords.x]
          // );
          // console.log("\n");


          var ns = {
            x: this.curStatePrevCords.x + a[1],
            y: this.curStatePrevCords.y + a[0]
          };

          if (ns.x >= 0 && ns.x < 10 && ns.y >= 0 && ns.y < 10) {
            if (!this.inBlocking(ns) && !(this.game.is_in_ow(this.curStatePrevCords) && !this.game.is_in_ow(ns))) this.curStatePrevCords = ns;
          }
        }
      }
    }
  }, {
    key: "executeTraj",
    value: function executeTraj(traj) {
      //spawn vehicle at position
      // console.log(this.i);
      if (this.i === 0) {
        var spawnPoint = {
          x: traj[0][1],
          y: traj[0][0]
        };
        this.trajCords.push(spawnPoint); // console.log(spawnPoint);

        this.vehicle.position = spawnPoint;
        this.vehicle.goal = spawnPoint;
        this.vehicle.just_spawned = false;
        this.i += 1;
        this.curStatePrevCords = spawnPoint; // this.actions.push(null);
      } //respawn vehicle back at the beggining


      if (this.i === this.trajLength + 1) {
        var _spawnPoint = {
          x: traj[0][1],
          y: traj[0][0]
        };
        this.vehicle.position = _spawnPoint;
        this.vehicle.goal = _spawnPoint;
        this.vehicle.img = document.getElementById(this.pos2img[this.firstAction]);
        this.vehicle.size_x = this.pos2dim[this.firstAction].x;
        this.vehicle.size_y = this.pos2dim[this.firstAction].y;
        this.vehicle.just_spawned = true;
        return;
      } //execute actions


      var a = traj[this.i]; //----------------------------------------------------

      if (this.prevI !== this.i) this.updateScore(a); // console.log(this.i);

      if (a[0] === 0 && a[1] === 1 && this.vehicle.updatedScore === true) {
        // console.log("right");
        if (this.i === 1) {
          this.firstAction = "right";
        }

        this.vehicle.moveRight();
        if (this.vehicle.isDone) this.actions.push("right");
      }

      if (a[0] === 0 && a[1] === -1 && this.vehicle.updatedScore === true) {
        // console.log("left");
        if (this.i === 1) {
          this.firstAction = "left";
        }

        this.vehicle.moveLeft();
        if (this.vehicle.isDone) this.actions.push("left");
      }

      if (a[0] === 1 && a[1] === 0 && this.vehicle.updatedScore === true) {
        // console.log("down");
        if (this.i === 1) {
          this.firstAction = "down";
        }

        this.vehicle.moveDown(); // console.log("here");

        if (this.vehicle.isDone) this.actions.push("down");
      }

      if (a[0] === -1 && a[1] === 0 && this.vehicle.updatedScore === true) {
        // console.log("up");
        if (this.i === 1) {
          this.firstAction = "up";
        }

        this.vehicle.moveUp();
        if (this.vehicle.isDone) this.actions.push("up");
      }

      var trajPoint = this.vehicle.goal;

      if (this.inBlocking(trajPoint) === true) {
        if (this.inBlocking(this.vehicle.lastCol)) return;
        trajPoint = this.vehicle.lastCol; // console.log(trajPoint);
      }

      var dup = false;

      if (this.trajCords[this.trajCords.length - 1].x === trajPoint.x && this.trajCords[this.trajCords.length - 1].y === trajPoint.y) {
        dup = true;
      } // console.log(this.incompleteCords);
      // console.log(this.incompleteActions);


      if (dup === false) this.trajCords.push(trajPoint);
    }
  }, {
    key: "isIncomplete",
    value: function isIncomplete(cords, a) {
      var is_inc = false; // console.log(this.incompleteCords.length);

      for (var i = 0; i < this.incompleteCords.length; i++) {
        // use array[i] here
        var blocking_pos = this.incompleteCords[i]; //&& this.incompleteActions[i] === a

        if (blocking_pos.x === cords.x && blocking_pos.y === cords.y && this.incompleteActions[i] === a) {
          is_inc = true;
        }
      }

      return is_inc;
    }
  }, {
    key: "drawSVG",
    value: function drawSVG(ctx) {
      this.svgArrow(ctx, 100, 100, 200, 250);
      var svgElement = document.getElementById("SVG");

      var _svgElement$getBBox = svgElement.getBBox(),
          width = _svgElement$getBBox.width,
          height = _svgElement$getBBox.height;

      var clonedSvgElement = svgElement.cloneNode(true);
      var outerHTML = clonedSvgElement.outerHTML,
          blob = new Blob([outerHTML], {
        type: "image/svg+xml;charset=utf-8"
      });
      var URL = window.URL || window.webkitURL || window;
      var blobURL = URL.createObjectURL(blob);
      var image = new Image(); // image.onload = () => {
      // let canvas = document.createElement("canvas");
      // canvas.widht = width;
      // canvas.height = height;
      // let context = canvas.getContext("2d");
      // draw image in canvas starting left-0 , top - 0

      image.src = blobURL;
      ctx.drawImage(image, 0, 0, 200, 200); //  downloadImage(canvas); need to implement
      //};
    }
  }, {
    key: "svgArrow",
    value: function svgArrow(context, p1x, p1y, p2x, p2y) {
      // var p1x = parseFloat(document.getElementById("au").getAttribute("cx"));
      // var p1y = parseFloat(document.getElementById("au").getAttribute("cy"));
      // var p2x = parseFloat(document.getElementById("sl").getAttribute("cx"));
      // var p2y = parseFloat(document.getElementById("sl").getAttribute("cy"));
      // mid-point of line:
      var mpx = (p2x + p1x) * 0.5;
      var mpy = (p2y + p1y) * 0.5; // angle of perpendicular to line:

      var theta = Math.atan2(p2y - p1y, p2x - p1x) - Math.PI / 2; // distance of control point from mid-point of line:

      var offset = 30; // location of control point:

      var c1x = mpx + offset * Math.cos(theta);
      var c1y = mpy + offset * Math.sin(theta); // show where the control point is:
      // var c1 = document.getElementById("cp");
      // c1.setAttribute("cx", c1x);
      // c1.setAttribute("cy", c1y);
      // construct the command to draw a quadratic curve

      var curve = "M" + p1x + " " + p1y + " Q " + c1x + " " + c1y + " " + p2x + " " + p2y;
      var curveElement = document.getElementById("curve");
      curveElement.setAttribute("d", curve);
    }
  }, {
    key: "trajBounds",
    value: function trajBounds() {
      var lowestX = null;
      var lowestY = null;
      var highestX = -1;
      var highestY = -1;

      for (var i = 0; i < this.trajCords.length; i++) {
        var c = this.trajCords[i];

        if (lowestY === null || c.y < lowestY) {
          lowestY = c.y;
        }

        if (c.y > highestY) {
          highestY = c.y;
        }

        if (c.x > highestX) {
          highestX = c.x;
        }

        if (lowestX === null || c.x < lowestX) {
          lowestX = c.x;
        }
      }

      return {
        lx: lowestX,
        ly: lowestY,
        hx: highestX,
        hy: highestY
      };
    }
  }, {
    key: "cord2canvas",
    value: function cord2canvas(val, size) {
      return this.cellSize * val + this.cellSize / 2 - size / 2;
    }
  }, {
    key: "maskOutBg",
    value: function maskOutBg(ctx) {
      var rectCords = this.trajBounds(); //overlay
      //lighten

      ctx.globalCompositeOperation = "saturation";
      ctx.beginPath();
      var box1h;

      if (rectCords.lx === 0) {
        box1h = this.cord2canvas(rectCords.ly - 0.5, 0);
      } else {
        box1h = this.game.gameHeight;
      } //left rect


      ctx.rect(0, 0, this.cord2canvas(rectCords.lx - 0.5, 0), box1h); //bottom rect

      ctx.rect(0, this.cord2canvas(rectCords.hy + 0.5, 0), this.game.gameWidth, this.game.gameHeight); //right rect

      var box3h;

      if (rectCords.hx === 9) {
        box3h = this.cord2canvas(rectCords.ly + 0.5, 0);
      } else {
        box3h = this.game.gameHeight;
      }

      ctx.rect(this.cord2canvas(rectCords.hx + 0.5, 0), 0, this.game.gameWidth, box3h);
      var box4h;

      if (rectCords.ly === 0) {
        box4h = 0;
      } else {
        box4h = this.cord2canvas(rectCords.ly + 0.5, 0);
      } //top rect


      ctx.rect(this.cord2canvas(rectCords.lx - 1 + 0.5, 0), 0, this.game.gameWidth, box4h);
      ctx.fillStyle = "whitesmoke";
      ctx.fill();
    }
  }, {
    key: "recolorCanvas",
    value: function recolorCanvas(ctx) {
      ctx.globalAlpha = 0.15;
      ctx.globalCompositeOperation = "saturation"; // ctx.beginPath();
      // ctx.rect(0, 0, this.game.gameWidth, this.game.gameHeight);
      // ctx.fillStyle = "whitesmoke";
      // ctx.fill();
    }
  }, {
    key: "handelSameDir",
    value: function handelSameDir(p1, p2, ctx) {
      var first = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      if (p1 === undefined || p2 === undefined || p1.inc === true || p2.inc === true) return;

      if (p1.a === "left" && p2.a === "right" || p1.a === "right" && p2.a === "left") {
        if (first) this.sameDirYoffset = -8;else this.sameDirYoffset = 8;
      } else if (p1.a === "up" && p2.a === "down" || p1.a === "down" && p2.a === "up") {
        // console.log("here");
        if (first) this.sameDirXoffset = -8;else this.sameDirXoffset = 8;
      }
    }
  }, {
    key: "handelMulSameDir",
    value: function handelMulSameDir(p1, p2, p3, ctx) {
      var first = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;

      if ((p1.a === "left" && p2.a === "right" || p1.a === "right" && p2.a === "left") && (p3.a === "left" || p3.a === "right")) {
        this.sameDirYoffset = 0;
      } else if ((p1.a === "up" && p2.a === "down" || p1.a === "down" && p2.a === "up") && (p3.a === "up" || p3.a === "down")) {
        // console.log("here");
        this.sameDirXoffset = 0;
      }
    }
  }, {
    key: "canvasArrow",
    value: function canvasArrow(ctx, p1, p2) {
      var p3 = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      var p4 = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;
      this.sameDirXoffset = 0;
      this.sameDirYoffset = 0;
      var x;
      var y;

      if (p1 != null) {
        x = this.cord2canvas(p1.x, 0);
        y = this.cord2canvas(p1.y, 0);
      }

      var xn = this.cord2canvas(p2.x, 0);
      var yn = this.cord2canvas(p2.y, 0);
      ctx.beginPath();
      ctx.setLineDash([5, 5]);
      ctx.lineWidth = 5; // console.log("here");

      if (p1 != null && p1.inc === true && p2.inc === true) {
        return;
      }

      if (p3 != null) {
        this.handelSameDir(p1, p3, ctx); //if prev is incomplete, compare current to prev prev

        if (this.lastInc === true) this.handelSameDir(p2, p3, ctx);
      }

      if (p1 != null) {
        this.handelSameDir(p1, p2, ctx, true); //if current is incomplete, compare prev to next

        if (p4 !== null && p2.inc === true) this.handelSameDir(p1, p4, ctx, true);
      }

      if (p1 != null && p3 != null) this.handelMulSameDir(p1, p2, p3, ctx);

      if (p1 != null && p1.inc && !p2.inc) {
        // console.log("here");
        //previous point is incomplete
        // console.log("here");
        if (p2.y - 1 === p1.y) {
          // console.log("here");
          ctx.moveTo(x + this.sameDirXoffset, y + 20 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn + this.sameDirYoffset);
        }

        if (p1.y - 1 === p2.y) {
          ctx.moveTo(x + this.sameDirXoffset, y + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn + this.sameDirYoffset);
        } //moving from left to rigjt


        if (p2.x - 1 === p1.x) {
          // console.log("here");
          ctx.moveTo(x + 5 + this.sameDirXoffset, y - 2 + this.sameDirYoffset);
          ctx.lineTo(xn - 20 + this.sameDirXoffset, yn - 2 + this.sameDirYoffset);
        } //moving from right to left


        if (p1.x - 1 === p2.x) {
          // console.log("here");
          // ctx.moveTo(x, y - 10);
          // ctx.lineTo(x, y - 2);
          ctx.moveTo(x + this.sameDirXoffset, y - 2 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn - 2 + this.sameDirYoffset);
        }
      } else if (p1 != null && p2.inc && !p1.inc) {
        // console.log("here");
        if (p2.x - 1 === p1.x) {
          ctx.moveTo(x + this.sameDirXoffset, y - 2 + this.sameDirYoffset);
          ctx.lineTo(xn + 5 + this.sameDirXoffset, yn - 2 + this.sameDirYoffset);
        }

        if (p2.y - 1 === p1.y) {
          // console.log("here");
          ctx.moveTo(x + this.sameDirXoffset, y - 5 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn + this.sameDirYoffset);
        }

        if (p1.y - 1 === p2.y) {
          // console.log("here");
          ctx.moveTo(x + this.sameDirXoffset, y - 5 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn + this.sameDirYoffset);
        } //moving from right to left


        if (p1.x - 1 === p2.x) {
          // console.log("here");
          ctx.moveTo(x - 5 + this.sameDirXoffset, y - 2 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn - 2 + this.sameDirYoffset);
        } // console.log("here");

      } else {
        //check for prevprev (s,a) pair
        // if (p3 != null && p3.inc === false) {
        //   this.handelSameDir(p2, p3, ctx);
        // }
        // if (p3 != null && p3.inc === false) {
        //   this.handelSameDir(p1, p3, ctx);
        // }
        // if (p1 != null && p1.inc === false) {
        //   this.handelSameDir(p1, p2, ctx, true);
        // }
        if (p1 != null && p1.x !== p2.x) {
          // console.log("here");
          // console.log(p1.a);
          // console.log(p2.a);
          // console.log("\n");
          ctx.moveTo(x + this.sameDirXoffset, y - 3 + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn - 3 + this.sameDirYoffset);
        } else if (p1 != null && p1.y !== p2.y) {
          // console.log("here");
          ctx.moveTo(x + this.sameDirXoffset, y + this.sameDirYoffset);
          ctx.lineTo(xn + this.sameDirXoffset, yn + this.sameDirYoffset);
        }
      }

      ctx.stroke();
    }
  }, {
    key: "drawTriangle",
    value: function drawTriangle(ctx, tipCordX, tipCordY, xDir, yDir) {
      ctx.beginPath();
      var offset1 = 0;
      var offset2 = 0;
      var offset3 = 0;
      var offset4 = 0;
      var offset5 = 0;
      var offset6 = 0;
      var offset7 = 0;
      var label_offset_x = 0;
      var label_offset_y = 0;

      if (xDir > 0) {
        offset1 = 15;
        offset2 = -30;
        offset3 = -10;
        label_offset_x = -12;
        label_offset_y = 2;
      } else if (xDir < 0) {
        offset1 = 0;
        offset2 = 0;
        offset3 = 10;
        label_offset_x = 8;
        label_offset_y = 2;
      } else if (yDir > 0) {
        // console.log("here");
        offset2 = -3.5;
        offset3 = 10;
        offset4 = 10 - 10;
        offset5 = -24;
        offset6 = -4;
        offset7 = -25;
        label_offset_x = -2;
        label_offset_y = -7;
      } else if (yDir < 0) {
        // console.log("here");
        offset2 = -3.5;
        offset3 = 10;
        offset4 = -5 + 10;
        offset5 = -24;
        offset6 = 24;
        offset7 = 5;
        label_offset_x = -2;
        label_offset_y = 11;
      } // ctx.fillStyle = prevFill;


      var prevFill = ctx.fillStyle.valueOf();
      tipCordY = tipCordY + 5 + offset4 + this.sameDirYoffset;
      tipCordX = tipCordX + offset3 + offset1 + this.sameDirXoffset;
      var arrowLength = 15;
      var arrowHeight = 20;
      ctx.moveTo(tipCordX, tipCordY);
      ctx.lineTo(tipCordX + arrowLength + offset2, offset7 + tipCordY + arrowHeight / 2);
      ctx.lineTo(tipCordX + arrowLength + offset2 + offset5, offset6 + tipCordY - arrowHeight / 2);
      ctx.fill();
      ctx.font = "9px CustomFont";
      ctx.fillStyle = "white";
      var text;
      if (prevFill === "#c0a948") text = "1";else if (prevFill === "#c0aac2") text = "2";else text = 3; // console.log(text);

      ctx.fillText(text, tipCordX + label_offset_x, tipCordY + label_offset_y);
      ctx.fillStyle = prevFill;
    }
  }, {
    key: "inBlocking",
    value: function inBlocking(cords) {
      for (var i = 0; i < this.game.blockingCords.length; i++) {
        if (cords.x === this.game.blockingCords[i].x && cords.y === this.game.blockingCords[i].y) {
          return true;
        }
      }

      return false;
    }
  }, {
    key: "remove",
    value: function remove(arr, cords) {
      var ret = [];

      for (var i = 0; i < arr.length; i++) {
        if (!(arr[i].x === cords.x && arr[i].y === cords.y && arr[i].inc === cords.inc)) {
          ret.push(arr[i]);
        }
      }

      return ret;
    }
  }, {
    key: "drawX",
    value: function drawX(ctx, x, y) {
      var size = 6;
      ctx.setLineDash([]);
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(x - size + 10, y - size + 5);
      ctx.lineTo(x + size + 10, y + size + 5);
      ctx.moveTo(x + size + 10, y - size + 5);
      ctx.lineTo(x - size + 10, y + size + 5);
      ctx.stroke();
      ctx.setLineDash([5, 5]);
    }
  }, {
    key: "updateColors",
    value: function updateColors(ctx) {
      var replace = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var increment = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;

      // console.log(this.fillStyles[this.nStyles]);
      while (this.styleStatus[this.nStyles] === true) {
        this.nStyles += 1;
      }

      ctx.fillStyle = this.fillStyles[this.nStyles];
      ctx.strokeStyle = this.fillStyles[this.nStyles];
      this.styleStatus[this.nStyles] = true; // if (replace) {
      //   this.fillStyles[this.nStyles] = this.fillStyles[this.nStyles + 1];
      // }

      this.nStyles += increment;
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      // this.maskOutBg(ctx);
      ctx.globalAlpha = 1;
      var centers = []; // console.log(this.trajCords.length);

      this.nStyles = 0; // this.updateColors(ctx);

      var nMoreCols = 3 - this.trajCords.length; // this.fillStyles = ["darkgreen", "darkseagreen", "lightcoral", "indianred"];

      this.fillStyles = ["rgb(192, 169, 72)", "rgb(192, 170, 194)", "rgb(127, 117, 251)"];
      this.styleStatus = [false, false, false, false]; //find centers of trajectory
      // console.log(this.trajCords);

      for (var n = 0; n < this.trajCords.length; n++) {
        var cords = this.trajCords[n]; // console.log(cords);
        // let cordsX = this.cord2canvas(cords.x, 20);
        // let cordsY = this.cord2canvas(cords.y, 15);
        // let drawArrow = false;
        // let inc = false;

        var a = this.actions[n];

        if (this.isIncomplete(cords, a)) {
          centers.push({
            x: cords.x,
            y: cords.y,
            inc: true,
            a: a
          });

          if (n !== 0) {
            //if cords not in blocking or ow, it must have been one way
            if (!this.inBlocking(cords) && !this.game.find_is_leaving_ow(cords)) {
              centers.push({
                x: this.trajCords[n].x,
                y: this.trajCords[n].y,
                inc: false,
                a: a
              });
            } else {
              centers.push({
                x: this.trajCords[n - 1].x,
                y: this.trajCords[n - 1].y,
                inc: false,
                a: a
              });
            } // drawArrow = true;

          }
        } else {
          // console.log(a);
          // console.log(n);
          // console.log("\n");
          centers.push({
            x: cords.x,
            y: cords.y,
            inc: false,
            a: a
          });
        }
      } // console.log(centers);
      // console.log(this.trajCords);


      for (var i = 0; i < this.trajCords.length; i++) {
        // console.log(cords);
        // this.updateColors(ctx);
        var _cords = this.trajCords[i]; // console.log(cords);

        var cordsX = this.cord2canvas(_cords.x, 20);
        var cordsY = this.cord2canvas(_cords.y, 15);
        var drawArrow = false;
        var inc = false;
        var _a = this.actions[i];
        var blockingCase = false; // console.log(a);
        // console.log(i);
        // console.log("\n");
        // console.log(this.actions.length);
        // console.log(this.isIncomplete(this.trajCords[2]));

        if (this.isIncomplete(_cords, _a)) {
          blockingCase = true; // console.log(a);

          inc = true;
          var offsetY = void 0;
          var offsetX = void 0;

          if (_a === "up") {
            offsetX = 0;
            if (this.inBlocking(_cords)) offsetY = 20;else offsetY = -20;
          } else if (_a === "down") {
            // console.log("here");
            offsetX = 0; //idk if this is right

            if (this.inBlocking(_cords)) offsetY = -20;else offsetY = 20;
          } else if (_a === "left") {
            offsetX = -20;
            offsetY = -2;
          } else if (_a === "right") {
            offsetX = 25;
            offsetY = 0;
          } // console.log(cords);


          if (i === 0) {
            this.updateColors(ctx, true, 1);
          } else {
            this.nStyles += 1;
            this.updateColors(ctx, true, -1);
          }

          this.drawX(ctx, cordsX + offsetX, cordsY + offsetY);
          drawArrow = true;

          for (var nCol = 0; nCol < nMoreCols; nCol++) {
            if (i === 0) {
              this.updateColors(ctx, true, 1);
            } else {
              this.nStyles += nCol + 2;
              this.updateColors(ctx, true, -(nCol + 2));
            }

            this.drawX(ctx, cordsX + offsetX + 7 * (nCol + 1), cordsY + offsetY);
          }
        } // else {
        //   if (i !== 0) {
        //     // console.log(cords);
        //     drawArrow = true;
        //   }
        // }


        var currentCords = centers[i];

        if (i > 0) {
          // console.log(centers[i].a);
          // console.log(i);
          // console.log("\n");
          var x = -1;
          var _n = 1;
          var prevCords = centers[i - 1];
          this.updateColors(ctx);

          if (i > 1) {
            // console.log(currentCords);
            if (prevCords.inc === true) x = -2; //add another negative one to prevprev if currentCords.inc === true

            this.canvasArrow(ctx, prevCords, currentCords, centers[i - 2], null);
          } else {
            //this handles the case where we have left-> up (collision) ->right
            if (currentCords.inc === true) _n = 2;
            this.canvasArrow(ctx, prevCords, currentCords, null, centers[i + _n]);
          } // console.log(cords);


          this.drawTriangle(ctx, cordsX, cordsY, currentCords.x - prevCords.x, currentCords.y - prevCords.y);

          if (currentCords.inc === true) {
            centers = this.remove(centers, currentCords);
            this.lastInc = true; //this flag needs to be here becuase we remove the incomplete points
          } else {
            this.lastInc = false;
          }
        }
      }

      this.recolorCanvas(ctx);
    } // saveBase64AsFile(base64, fileName) {
    //   var link = document.createElement("a");
    //   document.body.appendChild(link);
    //   link.setAttribute("type", "hidden");
    //   link.href = "data:text/plain;base64," + base64;
    //   link.download = fileName;
    //   link.click();
    //   document.body.removeChild(link);
    // }

  }, {
    key: "update",
    value: function update(deltaTime) {
      //NOTE!! FOR DEBUGGING PURPOSES - DONT FORGET
      if (this.quadI === 0) {
        this.cordsI = 0;
        this.quadI = 0;
        this.trajp = 0; // if (!this.tookScreenShot) {
        //   this.cur_name = "/trajImages/" +
        //     String(this.keys[this.cordsI]) +
        //     "_" +
        //     String(this.quadI) +
        //     "_" +
        //     String(this.trajp);
        //   screenshot({format: 'png'}).then((img) => {
        //     // img: Buffer filled with jpg goodness
        //     fs.writeFile('out.jpg', img, function (err) {
        //       if (err) {
        //         throw err
        //       }
        //       console.log('written to out.jpg')
        //     })
        //     // ...
        //   }).catch((err) => {
        //     console.log(err);
        //   })
        //
        //   this.tookScreenShot = true;
        // }
      }

      if (this.i < this.trajLength + 2 && this.loadedRFunc && this.loadedTrajData) {
        var traj1 = this.json[this.keys[this.cordsI]][this.quadI][this.trajp];
        this.executeTraj(traj1);
      }

      if (this.vehicle.isDone === true && this.vehicle.updatedScore === true && this.loadedRFunc && this.loadedTrajData) {
        // if (this.i === this.trajLength + 2) {
        //   this.tookScreenShot = false;
        // }
        if (this.i < this.trajLength + 2) {
          this.i += 1;
        } // else if (this.trajp === 0) {
        //   this.trajp = 1;
        //   this.i = 0;
        //   this.trajCords = []
        // } else if (this.quadI < this.json[this.keys[this.cordsI]].length - 1) {
        //   this.quadI += 1;
        //   this.trajp = 0;
        //   this.i = 0;
        // } else if (this.cordsI < this.json.length - 1) {
        //   this.cordsI += 1;
        //   this.quadI = 0;
        //   this.trajp = 0;
        //   this.i = 0;
        // }

      }
    }
  }]);

  return TrajHandler;
}();

exports.default = TrajHandler;
},{}],"src/game.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _vehicle = _interopRequireDefault(require("/src/vehicle"));

var _house = _interopRequireDefault(require("/src/house"));

var _flag = _interopRequireDefault(require("/src/flag"));

var _person = _interopRequireDefault(require("/src/person"));

var _coin = _interopRequireDefault(require("/src/coin"));

var _garbage = _interopRequireDefault(require("/src/garbage"));

var _owTile = _interopRequireDefault(require("/src/owTile"));

var _input = _interopRequireDefault(require("/src/input"));

var _trajHandler = _interopRequireDefault(require("/src/trajHandler"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Game = /*#__PURE__*/function () {
  function Game(gameWidth, gameHeight, spawnPoint, boardName, dispTraj) {
    _classCallCheck(this, Game);

    this.gameWidth = gameWidth;
    this.gameHeight = gameHeight;
    this.spawnPoint = spawnPoint;
    this.boardName = boardName; // this.is_in_blocking = false;

    this.reached_terminal = false;
    this.nSteps = 0;
    this.collectedCoin = false;
    this.dispTraj = dispTraj;
    this.blockingCords = [];
    this.isLeavingBlank = false; //metrics used to see if the user completing our assigned goals

    this.hitPerson = false;
    this.hitFlag = false;
    this.hitHouse = false;
    this.hitEdge = false;
    this.triedLeaving = false;
  } //   fetchJSONFile(path, callback) {
  //     var httpRequest = new XMLHttpRequest();
  //     httpRequest.onreadystatechange = function() {
  //         if (httpRequest.readyState === 4) {
  //             if (httpRequest.status === 200) {
  //                 var data = JSON.parse(httpRequest.responseText);
  //                 if (callback) callback(data);
  //             }
  //         }
  //     };
  //     httpRequest.open('GET', path);
  //     httpRequest.send();
  // }


  _createClass(Game, [{
    key: "start",
    value: function start() {
      var _this = this;

      var ins = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
      var dispIns = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      var loadTerm = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var isAnimating = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      // if (window.n_games === 7)return;
      this.gameObjects = null;
      this.vehicle = new _vehicle.default(this, isAnimating); // this.coin = new Coin(this, { x: 0, y: 0 });

      this.score = 0;
      this.gasScore = 0;
      this.pScore = 0;
      if (this.dispTraj === false) new _input.default(this.vehicle); // this.board_objects = this.load_board();
      // this.fetchJSONFile(("/assets/boards/" + String(this.boardName) + "_board.json", function(data){
      // // do something with your data
      // console.log(data);
      // });
      // var jsonData = JSON.parse(document.getElementById('data').textContent)
      // console.log(jsonData);
      // Assume the async call always succeed

      this.load_board(loadTerm).then(function () {
        _this.gameObjects = [].concat(_toConsumableArray(_this.board_objects), [_this.vehicle]);
      });
      this.trajHandler = new _trajHandler.default(this.vehicle, this);

      if (window.n_games !== 11 && dispIns) {
        // document.getElementById("displayInsBtn").style.display = "block";
        // displayInsBtn
        $(".displayInsBtn").show();
        $("#myModal").on('show.bs.modal', function (e) {
          var modal = $(this); // modal.find('.label1').text(ins)
          // modal.find('.modal_img1').attr("src","assets/images/img_flag.png")

          $(".img-responsive").attr('src', ins); //modal_img1
        });
        $("#myModal").modal("show");
      }
    }
  }, {
    key: "update",
    value: function update(deltaTime) {
      this.collectedCoin = false;
      if (this.dispTraj === true) this.trajHandler.update(deltaTime);
      this.gameObjects.forEach(function (object) {
        return object.update(deltaTime);
      }); //update oneway gates

      if (this.is_in_ow(this.vehicle.lastCol) || this.is_in_ow(this.spawnPoint)) {
        this.ow_obs.forEach(function (object) {
          return object.blockade = document.getElementById("img_blockade_closed");
        });
      }

      if (this.dispTraj === true) {
        this.score = this.trajHandler.score;
        this.pScore = this.trajHandler.pScore;
        this.gasScore = this.trajHandler.gasScore;
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.globalCompositeOperation = "source-over";
      this.gameObjects.forEach(function (object) {
        return object.draw(ctx);
      });
      if (this.dispTraj === true) this.trajHandler.draw(ctx);
    }
  }, {
    key: "is_in_ow",
    value: function is_in_ow(cords) {
      // console.log(cords);
      for (var i = 0; i < this.ow_cords.length; i++) {
        var ow_pos = this.ow_cords[i];

        if (ow_pos.x === cords.x && ow_pos.y === cords.y) {
          return true;
        }
      }

      return false;
    }
  }, {
    key: "find_is_leaving_blank",
    value: function find_is_leaving_blank(nextCords) {
      if (!this.is_in_ow(this.vehicle.lastCol) && this.is_in_ow(nextCords)) {
        this.isLeavingBlank = true;
      } else {
        // console.log(this.vehicle.lastCol);
        this.isLeavingBlank = false;
      }
    }
  }, {
    key: "find_is_leaving_ow",
    value: function find_is_leaving_ow(nextCords) {
      //check if the car is trying to leave a oneway area
      if (!this.is_in_ow(nextCords) && this.is_in_ow(this.vehicle.lastCol)) {
        this.isLeaving = true;
      } else {
        // console.log(this.vehicle.lastCol);
        this.isLeaving = false;
      }
    }
  }, {
    key: "load_board",
    value: function () {
      var _load_board = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(loadTerm) {
        var _this2 = this;

        var objects, json, board, i, row, j;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                objects = []; //https://api.jsonbin.io/b/60ca6d8f8ea8ec25bd0e7835
                //
                //"/assets/boards/" + String(this.boardName) + "_board.json"

                _context.next = 3;
                return fetch('https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/boards/' + String(this.boardName) + '_board.json');

              case 3:
                _context.next = 5;
                return _context.sent.json();

              case 5:
                json = _context.sent;
                // console.log(json)
                // fetch('https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/boards/' + String(this.boardName) + '.json')
                // .then(response => response.json())
                // .then(data =>  this.json = data);
                // var json = require("/assets/boards/test_json_board.json");
                board = []; // var blocking_cords = [];

                this.blocking_cords = [];
                this.terminal_cords = [];
                this.ow_cords = [];
                this.ow_obs = []; //loads json

                for (i in json) {
                  row = [];

                  for (j in json[i]) {
                    row.push(json[i][j]);
                  }

                  board.push(row);
                }

                board.forEach(function (row, rowIndex) {
                  row.forEach(function (item, itemIndex) {
                    var position = {
                      x: itemIndex,
                      y: rowIndex
                    };

                    if (item === 1) {
                      if (loadTerm) {
                        objects.push(new _flag.default(_this2, position));

                        _this2.terminal_cords.push(position);
                      } // console.log(position);

                    }

                    if (item === 2) {
                      objects.push(new _house.default(_this2, position));

                      _this2.blocking_cords.push(position);
                    }

                    if (item === 3) {
                      if (loadTerm) {
                        objects.push(new _person.default(_this2, position));

                        _this2.terminal_cords.push(position);
                      }
                    }

                    if (item === 4) {
                      objects.push(new _coin.default(_this2, position));
                    }

                    if (item === 5) {
                      objects.push(new _garbage.default(_this2, position));
                    }

                    if (item === 6) {
                      var tile = new _owTile.default(_this2, position);
                      objects.push(tile);

                      _this2.ow_cords.push(position);

                      _this2.ow_obs.push(tile);
                    }

                    if (item === 7) {
                      var _tile = new _owTile.default(_this2, position);

                      objects.push(_tile);
                      objects.push(new _flag.default(_this2, position));

                      _this2.terminal_cords.push(position);

                      _this2.ow_cords.push(position);

                      _this2.ow_obs.push(_tile);
                    }

                    if (item === 8) {
                      var _tile2 = new _owTile.default(_this2, position);

                      objects.push(_tile2);
                      objects.push(new _house.default(_this2, position));

                      _this2.blocking_cords.push(position);

                      _this2.ow_cords.push(position);

                      _this2.ow_obs.push(_tile2);
                    }

                    if (item === 9) {
                      var _tile3 = new _owTile.default(_this2, position);

                      objects.push(_tile3);

                      if (loadTerm) {
                        objects.push(new _person.default(_this2, position));

                        _this2.terminal_cords.push(position);

                        _this2.ow_obs.push(_tile3);
                      }

                      _this2.ow_cords.push(position);
                    }

                    if (item === 10) {
                      var _tile4 = new _owTile.default(_this2, position);

                      objects.push(_tile4);
                      objects.push(new _coin.default(_this2, position));

                      _this2.ow_cords.push(position);

                      _this2.ow_obs.push(_tile4);
                    }

                    if (item === 11) {
                      var _tile5 = new _owTile.default(_this2, position);

                      objects.push(_tile5);
                      objects.push(new _garbage.default(_this2, position));

                      _this2.ow_cords.push(position);

                      _this2.ow_obs.push(_tile5);
                    }
                  });
                });
                this.board_objects = objects;

              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function load_board(_x) {
        return _load_board.apply(this, arguments);
      }

      return load_board;
    }()
  }]);

  return Game;
}();

exports.default = Game;
},{"/src/vehicle":"src/vehicle.js","/src/house":"src/house.js","/src/flag":"src/flag.js","/src/person":"src/person.js","/src/coin":"src/coin.js","/src/garbage":"src/garbage.js","/src/owTile":"src/owTile.js","/src/input":"src/input.js","/src/trajHandler":"src/trajHandler.js"}],"src/score.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Score = /*#__PURE__*/function () {
  function Score(game, scoreWidth) {
    _classCallCheck(this, Score);

    this.game = game;
  }

  _createClass(Score, [{
    key: "start",
    value: function start() {
      this.score = 0;
      this.prevScore = 0;
      this.prevprevScore = 0;
      this.lastx = 0;
      this.lasty = 0;
      this.lastw = 0;
      this.lasth = 0;
      this.startY = 300;
      this.decomposedScore = false;
      this.printDecomposed = true;
      this.gasScore = 0;
      this.prevGasScore = 0;
      this.pScore = 0;
      this.prevPScore = 0;
      this.maxHeight = 500;
      this.updateAll = false;
    }
  }, {
    key: "drawRect",
    value: function drawRect(ctx, x, y, w, h, color) {
      if (color === "white") console.log("printing white rect!!");
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.fillRect(x, y, w, h);
      ctx.stroke();
    }
  }, {
    key: "barText",
    value: function barText(ctx, val, y_offset) {
      var text = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "";
      var fontSize = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "20px";
      ctx.font = fontSize + " CustomFont";
      var symbol = "$";

      if (val > 0) {
        ctx.fillStyle = "green";
        symbol = "+ $";
      }

      if (val < 0) {
        ctx.fillStyle = "red";
        symbol = "- $";
        val = -val;
      }

      if (val === 0) ctx.fillStyle = "brown";
      if (this.lasty > 20) ctx.fillText(text + symbol + String(val), 220, this.cap(this.lasty + y_offset));else ctx.fillText(text + symbol + String(val), 220, this.cap(this.startY + 10 + y_offset));
    }
  }, {
    key: "barImg",
    value: function barImg(ctx, id, y_offset) {
      var x = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 180;
      var size = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 30;
      var img = document.getElementById(id);
      if (this.lasty > 20) ctx.drawImage(img, x, this.cap(this.lasty + y_offset), size, size);else ctx.drawImage(img, x, this.cap(this.startY + 10 + y_offset), size, size);
    }
  }, {
    key: "drawGasTank",
    value: function drawGasTank(ctx, x) {
      if (this.decomposedScore === false) return;
      var y = this.maxHeight;
      var w = 120;
      var h = -5 * 100;
      this.drawRect(ctx, x, y, w, h, "darkolivegreen");
      y = y - 5 * 100;
      h = -5 * this.gasScore;
      this.drawRect(ctx, x, y, w, h, "grey");
      ctx.font = "20px CustomFont";
      ctx.fillStyle = "black"; // console.log("here");

      ctx.fillText("Gas: $" + String(this.gasScore), x + 10, 550 + 10 - 5 * this.gasScore - 450);
    }
  }, {
    key: "cap",
    value: function cap(y) {
      // return y;
      if (y > 500 || this.updateAll) {
        this.updateAll = true;
        var out = y - 500; // console.log(y);
        // console.log(500 + (y - 500));
        // console.log("\n");

        return 400 + out;
      }

      return y; // let max = 300;
      // if (Math.abs(val) + y > max) {
      //   if (val < 0) {
      //     val = -(max - y);
      //   } else {
      //     val = max - y;
      //   }
      // }
    }
  }, {
    key: "drawRects",
    value: function drawRects(ctx, x, w) {
      if (this.prevScore < 0) {
        // console.log(this.score);
        // console.log(this.prevscore);
        var py = this.startY - 5 * this.prevScore + 3;
        var ph = 5 * this.prevScore;
        this.drawRect(ctx, x, py, w, ph, "brown");

        if (this.delta < 0) {
          var y = py - 5 * (this.score - this.prevScore);
          var h = 5 * this.delta;
          this.drawRect(ctx, x, y, w, h, "red");
          this.lastx = x;
          this.lasty = y.valueOf();
          this.lastw = w;
          this.lasth = h.valueOf();
          this.color2draw = "red"; // this.subtracter = 0;
          // this.step = 0;
        } else if (this.delta > 0) {
          var _y;

          var _h;

          if (this.score > 0) {
            //jump over the bar
            _y = this.startY;
            _h = -5 * (this.delta - this.prevScore);
            ctx.clearRect(x, py, w, ph);
          } else {
            _y = this.startY - 5 * this.prevScore + 3;
            _h = -5 * this.delta;
          }

          this.drawRect(ctx, x, _y, w, _h, "green");
          this.lastx = x;
          this.lasty = _y.valueOf();
          this.lastw = w;
          this.lasth = _h.valueOf();
          this.color2draw = "green";
        }
      }

      if (this.prevScore > 0) {
        var _ph = -5 * this.prevScore;

        this.drawRect(ctx, x, this.startY, w, _ph, "brown");

        if (this.delta > 0) {
          var _y2 = this.startY + -5 * this.prevScore;

          var _h2 = -5 * this.delta;

          this.drawRect(ctx, x, _y2, w, _h2, "green"); // console.log(h);
          // console.log(y);

          this.lastx = x;
          this.lasty = _y2.valueOf();
          this.lastw = 120;
          this.lasth = _h2.valueOf();
          this.color2draw = "green";
        }

        if (this.delta < 0) {
          var _y3;

          var _h3;

          if (this.score < 0) {
            _y3 = this.startY + 3;
            _h3 = -5 * (this.delta - this.prevScore);
            ctx.clearRect(x, this.startY, w, _ph);
          } else {
            _y3 = this.startY + -5 * this.prevScore;
            _h3 = -5 * this.delta;
          }

          this.drawRect(ctx, x, _y3, w, _h3, "red");
          this.lastx = x;
          this.lasty = _y3.valueOf();
          this.lastw = 120;
          this.lasth = _h3.valueOf();
          this.color2draw = "red";
        }
      } //show newest part of score


      this.drawRect(ctx, this.lastx, this.lasty, this.lastw, this.lasth, this.color2draw);
    }
  }, {
    key: "setupLabels",
    value: function setupLabels(ctx, x, w) {
      if (this.game.dispTraj === false) {
        this.drawRect(ctx, x - 10, this.startY, 160, 3, "black");
      }

      ctx.font = "30px CustomFont";

      if (this.printDecomposed === true) {
        if (this.game.dispTraj === false) {
          ctx.font = "40px CustomFont";
          ctx.fillText("Score: $" + String(this.score), 10, 50);
          this.barImg(ctx, "img_gas", -25);
          this.barText(ctx, this.gasScore - this.prevGasScore, 0);
          this.barImg(ctx, "img_total", 10);
          this.barText(ctx, this.pScore - this.prevPScore, 30);
        } else {
          ctx.font = "40px CustomFont";
          ctx.fillStyle = "black";
          ctx.fillText("Score", 10, 50);
          ctx.fillText("Change: $" + String(this.score), 10, 90);
          this.barImg(ctx, "img_gas", -170, 130, 50);
          this.barText(ctx, this.gasScore, -140, "", "30px");
          this.barImg(ctx, "img_total", -100, 130, 50);
          this.barText(ctx, this.pScore, -70, "", "30px");
        }
      } else if (this.decomposedScore === true) {
        ctx.fillStyle = "brown";
        ctx.fillText("Total: $" + String(this.score), 10, 50);
        this.barText(ctx, this.delta, 0);
      } else {
        ctx.fillStyle = "brown";
        ctx.fillText("Score: $" + String(this.score), 10, 50);
        this.barText(ctx, this.delta, 0);
      }
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      this.drawGasTank(ctx, 200);
      var x = 10;
      var w = 140; // ctx.fillText("Score: $" + String(this.delta), 10, 100);
      //draw prevscore

      if (this.game.dispTraj === false) {
        this.drawRects(ctx, x, w);
        ctx.clearRect(10, 60, w, -100); // ctx.clearRect(10, 600, w, -20);

        ctx.fill();
        this.setupLabels(ctx, x, w);
      } else {
        this.setupLabels(ctx, x, w);
      }
    }
  }, {
    key: "update",
    value: function update() {
      if (this.game.vehicle.reachedGoal && this.game.vehicle.goal !== this.goalDrawn) {
        if (this.decomposedScore === true) {
          this.prevScore = this.pScore;
          this.score = this.game.pScore;
        } else {
          this.prevScore = this.score;
          this.score = this.game.score;
        }

        this.prevGasScore = this.gasScore;
        this.gasScore = this.game.gasScore;
        this.prevPScore = this.pScore;
        this.pScore = this.game.pScore;
        this.goalDrawn = this.game.vehicle.goal;
        this.delta = this.score - this.prevScore;
        this.lasth = 0;
      }
    }
  }]);

  return Score;
}();

exports.default = Score;
},{}],"src/instructionsManager.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _game = _interopRequireDefault(require("/src/game"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var InstructionManager = /*#__PURE__*/function () {
  function InstructionManager() {
    _classCallCheck(this, InstructionManager);

    this.finishedIns = false;
    this.insScene = 1;
    this.finishedGamePlay = false;
    this.animationGame = new _game.default(600, 600, {
      x: 0,
      y: 3
    }, "anim_examp", false);
    this.animationGame.start(false, true); // this.w = 1.252*window.gsWidth;
    // this.h = 0.751*window.gsHeight;
    // this.x = -0.125*window.gsWidth;
    // this.y = 0.083*window.gsHeight;
    // this.w = 750;
    // this.h = 450;
    // this.x = -75;
    // this.y = 50;
  } // createButton(canvas, ctx) {}


  _createClass(InstructionManager, [{
    key: "update",
    value: function update() {
      if (this.insScene === 10 && !this.finishedGamePlay) {
        this.finishedIns = true;
      }

      if (this.insScene === 11 && this.finishedGamePlay && !window.finishedTrajBoard) {
        this.finishedIns = true;
        window.playTrajBoard = true;
      }

      if (this.insScene === 14) {
        this.finishedIns = true;
        window.begunQueries = true;
      }

      this.img = document.getElementById("ins" + String(this.insScene)); // console.log("here");
    }
  }, {
    key: "playAnimation",
    value: function playAnimation(ctx) {
      this.animationGame.update();
      this.animationGame.draw(ctx);
    }
  }, {
    key: "draw",
    value: function draw(ctx) {
      if (this.insScene === 10 && !this.finishedGamePlay) return;
      if (this.insScene === 14) return;

      if (this.insScene === 4) {
        this.playAnimation(ctx); // this.h = 0.333*window.gsWidth;
        // this.w = 1.166*window.gsWidth;
        // this.x = -0.0666*window.gsWidth;
        // this.y = -0.0166*window.gsWidth;

        this.h = 200;
        this.w = 700;
        this.x = -40;
        this.y = -10;
      } else {
        //TODO: WE ONLY WANT TO DO THIS ON LOAD
        // if (!window.resizing) {
        //   this.w = 1.252*window.gsWidth;
        //   this.h = 0.751*window.gsWidth;
        //   this.x = -0.125*window.gsWidth;
        //   this.y = 0.083*window.gsWidth;
        //
        //
        // }
        //
        this.w = 750;
        this.h = 450;
        this.x = -75;
        this.y = 50;
      }

      ctx.drawImage(this.img, this.x, this.y, this.w, this.h); //draw button
      // ctx.fillStyle = "white";
      // ctx.beginPath();
      // ctx.rect(500, 550, 100, 50);
      // ctx.font = String(0.04166*window.gsWidth) + "px CustomFont";

      ctx.font = "20px CustomFont";
      ctx.fillStyle = "gray"; // console.log("here");

      if (this.insScene === 9) ctx.fillText("Play", 500, 570);else if (this.insScene === 10) ctx.fillText("Play", 500, 570);else if (this.insScene === 13) ctx.fillText("Begin", 500, 570);else ctx.fillText("Next", 500, 570); //500, 570
      //

      ctx.fill();
    }
  }]);

  return InstructionManager;
}();

exports.default = InstructionManager;
},{"/src/game":"src/game.js"}],"src/queryInput.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var QueryInputHandler = function QueryInputHandler() {
  _classCallCheck(this, QueryInputHandler);

  document.addEventListener("keydown", function (event) {
    switch (event.keyCode) {
      case 37:
        if (window.begunQueries) {
          window.qm.pressed = true;
          window.qm.queried("left");
        }

        break;

      case 38:
        if (window.begunQueries) {
          window.qm.pressed = true;
          window.qm.queried("dis");
        }

        break;

      case 39:
        if (window.begunQueries) {
          window.qm.pressed = true;
          window.qm.queried("right");
        }

        break;

      case 40:
        if (window.begunQueries) {
          window.qm.pressed = true;
          window.qm.queried("same");
        }

        break;
    }
  }); //
  // document.addEventListener("keyup", (event) => {
  //   switch (event.keyCode) {
  //     case 37:
  //       if (vehicle.speed.x < 0) {
  //         vehicle.stop();
  //       }
  //
  //       break;
  //     case 38:
  //       if (vehicle.speed.y < 0) {
  //         vehicle.stop();
  //       }
  //
  //       break;
  //     case 39:
  //       if (vehicle.speed.x > 0) {
  //         vehicle.stop();
  //       }
  //       break;
  //     case 40:
  //       if (vehicle.speed.y > 0) {
  //         vehicle.stop();
  //       }
  //   }
  // });
};

exports.default = QueryInputHandler;
},{}],"src/queryManager.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _queryInput = _interopRequireDefault(require("/src/queryInput"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var InstructionManager = /*#__PURE__*/function () {
  function InstructionManager() {
    _classCallCheck(this, InstructionManager);

    this.n_query = 0; // this.img = document.getElementById("img_ow_tile");

    this.nTrajs = 3;
    this.traj = 1;
    this.started = false;
    this.pressed = false; // ASSIGNS THE URL PARAMETERS TO JAVASCRIPT VARIABLES

    this.assignmentID = this.turkGetParam('assignmentId');
    this.b1Color = "grey";
    this.b2Color = "grey";
    this.b3Color = "grey";
    this.b4Color = "grey";
    this.isSubmitted = false; // this.offset = 0.416*window.qdWidth;
    // this.b1_x = 0.229*window.qdWidth;
    // this.b1_y = 0.714*window.qdHeight;
    // this.b1_h = 50
    // this.b1_w = 70
    // this.b2_x = (0.304*window.qdWidth)+this.offset
    // this.b3_x = 0.45*window.qdWidth
    // this.b3_y = 0.607*window.qdHeight;
    // this.b3_h = 130
    // this.b3_w = 50
    // this.b4_y = 0.714*window.qdHeight;

    this.offset = 500;
    this.b1_x = 200 + 420 / 2 - 70 / 2 - 100 - 125;
    this.b1_y = 500 - 100 + 15 + 40;
    this.b1_h = 50;
    this.b1_w = 70;
    this.b2_x = 290 + 420 / 2 - 70 / 2 - 100 + 500 - 125;
    this.b3_x = 720 - 160 / 2 - 100 - 125;
    this.b3_y = 425 - 100 + 15 + 40;
    this.b3_h = 130;
    this.b3_w = 50;
    this.b4_y = 500 - 100 + 15 + 40;
    new _queryInput.default();
  }

  _createClass(InstructionManager, [{
    key: "turkGetParam",
    value: function turkGetParam(name) {
      var fullurl = window.location.href;
      var regexS = "[\?&]" + name + "=([^&#]*)";
      var regex = new RegExp(regexS);
      var tmpURL = fullurl;
      var results = regex.exec(tmpURL);

      if (results == null) {
        return "";
      } else {
        return results[1];
      }
    }
  }, {
    key: "start",
    value: function start(deltaTime) {
      // this.offset = 0.495*window.qdWidth;
      // this.b1_x = 0.272*window.qdWidth;
      // this.b1_y = 1.02*window.qdHeight;
      // this.b1_h = 50
      // this.b1_w = 70
      // this.b2_x = 0.361*window.qdWidth+this.offset
      // this.b3_x = 0.535*window.qdWidth
      // this.b3_y = 0.869*window.qdHeight;
      // this.b3_h = 130
      // this.b3_w = 50
      // this.b4_y = 1.022*window.qdHeight;
      // window.canvas.width = window.innerWidth;
      // window.canvas.height = window.innerHeight;
      // window.canvas.width = 1200;
      // window.canvas.height = 700;
      window.canvas.style.display = "none";
      this.started = true;
      this.queryResults = {};
      this.lastDeltaTime = deltaTime;
      $("#myModal").on('show.bs.modal', function (e) {
        var modal = $(this); // modal.find('.label1').text(ins)
        // modal.find('.modal_img1').attr("src","assets/images/img_flag.png")

        $(".img-responsive").attr('src', "https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/query_ins.png"); //modal_img1
      });
      $("#myModal").modal("show");
    }
  }, {
    key: "submit",
    value: function submit() {
      // console.log(this.assignmentID);
      if (!this.isSubmitted) {
        document.getElementById('assignmentId').value = this.assignmentID; // for (var key in this.queryResults) {
        //   document.getElementById('foo').value = this.queryResults[key]
        //
        // }
        // document.forms[0].submit()

        document.getElementById('hitForm').submit();
        this.isSubmitted = true;
      }
    }
  }, {
    key: "resetButtons",
    value: function resetButtons() {
      this.b1Color = "grey";
      this.b2Color = "grey";
      this.b3Color = "grey";
      this.b4Color = "grey";
    }
  }, {
    key: "queried",
    value: function queried(data) {
      // this.queryResults["traj" + String(this.traj)] = data;
      if (data === "left") this.b1Color = "black";
      if (data === "right") this.b2Color = "black";
      if (data === "same") this.b3Color = "black";
      if (data === "dis") this.b4Color = "black";
      document.getElementById('query' + String(this.traj)).value = data;
    }
  }, {
    key: "update",
    value: function update(deltaTime) {
      if (!this.started) this.start(deltaTime); //
      // this.offset = 0.416*window.qdWidth;
      // this.b1_x = 0.229*window.qdWidth;
      // this.b1_y = 0.714*window.qdHeight;
      // this.b1_h = 50
      // this.b1_w = 70
      // this.b2_x = (0.304*window.qdWidth)+this.offset
      // this.b3_x = 0.45*window.qdWidth
      // this.b3_y = 0.607*window.qdHeight;
      // this.b3_h = 130
      // this.b3_w = 50
      // this.b4_y = 0.714*window.qdHeight;

      if (deltaTime - this.lastDeltaTime > 200) {
        this.resetButtons();
        this.lastDeltaTime = deltaTime;
      }

      if (this.pressed) {
        // console.log("pressed");
        // console.log(this.traj);
        if (this.traj === this.nTrajs) {
          this.submit();
        } else {
          this.traj += 1;
          this.pressed = false;
        }
      } // this.img.src = "/assets/trajImages/(0,2)_0_1.png"


      var trajId1 = "traj" + String(this.traj) + "0";
      var trajId2 = "traj" + String(this.traj) + "1";
      this.img1 = document.getElementById(trajId1);
      this.img2 = document.getElementById(trajId2);
    }
  }, {
    key: "drawButton",
    value: function drawButton(ctx, x, y, w, h, color, text, tx, ty) {
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.fillRect(x, y, w, h);
      ctx.stroke();
      ctx.font = "20px CustomFont";
      ctx.fillStyle = "white";
      ctx.fillText(text, tx, ty);
      ctx.fill();
    } // postRequest(data) {
    //
    //   router.post('https://workersandbox.mturk.com/mturk/externalSubmit',function(req,res,next) {
    //     var id = req.params.id;
    //     res.redirect("/test/...");
    //   });
    // }

  }, {
    key: "draw",
    value: function draw(ctx) {
      ctx.drawImage(this.img1, 200 - 100 - 100, 0, 350, 520);
      ctx.drawImage(this.img2, 290 + this.offset - 100 - 80, 0, 350, 520);
      this.drawButton(ctx, this.b1_x, this.b1_y, this.b1_w, this.b1_h, this.b1Color, "Left", this.b1_x - this.b1_w / 2 + 45, this.b1_y + this.b1_h / 2 + 5);
      this.drawButton(ctx, this.b2_x, this.b1_y, this.b1_w, this.b1_h, this.b2Color, "Right", this.b2_x - this.b1_w / 2 + 45, this.b1_y + this.b1_h / 2 + 5);
      this.drawButton(ctx, this.b3_x, this.b3_y, this.b3_h, this.b3_w, this.b3Color, "Same", this.b3_x + this.b3_h / 2 - 25, this.b3_y + this.b3_w / 2 + 5);
      this.drawButton(ctx, this.b3_x, this.b4_y, this.b3_h, this.b3_w, this.b4Color, "Can't Tell", this.b3_x + this.b3_h / 2 - 50, this.b4_y + this.b3_w / 2 + 5);
    }
  }]);

  return InstructionManager;
}();

exports.default = InstructionManager;
},{"/src/queryInput":"src/queryInput.js"}],"src/index.js":[function(require,module,exports) {
"use strict";

require("regenerator-runtime/runtime");

var _game = _interopRequireDefault(require("/src/game"));

var _score = _interopRequireDefault(require("/src/score"));

var _instructionsManager = _interopRequireDefault(require("/src/instructionsManager"));

var _queryManager = _interopRequireDefault(require("/src/queryManager"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import regeneratorRuntime from "regenerator-runtime";
//---------------------------------MTURK STUFF--------------------------------------
// var AWS = require('aws-sdk');
// var region_name = 'us-east-1';
// var endpoint = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com';
// // Uncomment this line to use in production
// //var endpoint = 'https://mturk-requester.us-east-1.amazonaws.com';
// AWS.config.update({ region: 'us-east-1',
// 		    endpoint: endpoint });
//
// var mturk = new AWS.MTurk();
// //
// let QUESTION_XML = '<ExternalQuestion' +
//  'xmlns="http://mechanicalturk.amazonaws.com/AWSMechanicalTurkDataSchemas/2006-07-14/ExternalQuestion.xsd">' +
//  '<ExternalURL>"https://dev.d1e16e31dm86sr.amplifyapp.com"</ExternalURL>' +
//  '<FrameHeight>500</FrameHeight>' + '</ExternalQuestion>'
//
//---------------------------------MTURK STUFF--------------------------------------
window.canvas = document.getElementById("gameScreen");
var ctx = window.canvas.getContext("2d");
var scoreDisp = document.getElementById("scoreScreen");
var ctxScore = scoreDisp.getContext("2d");
var queryDisp = document.getElementById("queryScreen");
var ctxQuery = queryDisp.getContext("2d"); // var svg = document.querySelector("svg");

var GAME_WIDTH = 600;
var GAME_HEIGHT = 600;
var QUERY_WIDTH = 1200;
var QUERY_HEIGHT = 700;
var SCORE_WIDTH = 300;
var SCORE_HEIGHT = 600; //width="300" height="600"

var CELL_SIZE = GAME_WIDTH / 10; //
//
// console.log(window.innerWidth);
// console.log(window.innerHeight);
//
// window.canvas.width = GAME_WIDTH;
// window.canvas.height = GAME_HEIGHT;
//
// window.canvas.width = 0.416*window.innerWidth
// window.canvas.height = 0.416*window.innerWidth
// console.log((window).width());
// console.log(window.innerWidth);

window.canvas.width = $(window).height();
window.canvas.height = $(window).height();
window.gsWidth = window.canvas.width;
window.gsHeight = window.canvas.height;
window.qdWidth = 0.75 * $(window).width();
window.qdHeight = 1 * $(window).height();
window.canvas.style.left = "18%";
window.canvas.style.top = "0%";
window.canvas.style.position = "absolute"; //
// scoreDisp.width = 300;
// scoreDisp.height = 600;

scoreDisp.width = 0.208 * $(window).width();
scoreDisp.height = $(window).height();
scoreDisp.style.left = "68%"; // scoreDist.style.left =  String((window.canvas.width/$(window).width()) + 10 + 10) + "%";
// console.log(String(10*(window.canvas.width/$(window).width()) + 10 + 10) + "%")

scoreDisp.style.top = "0%";
scoreDisp.style.position = "absolute"; // queryDisp.width = QUERY_WIDTH;
// queryDisp.height = QUERY_HEIGHT;

queryDisp.width = 0.75 * $(window).width();
queryDisp.height = 1 * $(window).height();
queryDisp.style.left = "15%";
queryDisp.style.top = "15%";
queryDisp.style.position = "absolute";
window.addEventListener("keydown", function (e) {
  if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].indexOf(e.code) > -1) {
    e.preventDefault();
  }
}, false);
window.addEventListener("load", function (event) {
  // window.im.w = 1.252*window.gsWidth;
  // window.im.h = 0.751*window.gsWidth;
  // window.im.x = -0.125*window.gsWidth;
  // window.im.y = 0.083*window.gsWidth;
  // window.im.nW =0.833*window.gsWidth;
  // window.im.nH =0.95*window.gsWidth;
  //
  ctx.canvas.width = 600;
  ctx.canvas.height = 600;
  ctxQuery.canvas.width = 1009;
  ctxQuery.canvas.height = 699;
  scoreDisp.width = 300;
  scoreDisp.height = 600;
  var gsRect = window.canvas.getBoundingClientRect();
  var gsLX = gsRect.left;
  var ssRect = scoreDisp.getBoundingClientRect();
  var ssLX = ssRect.left;
  var maxDist = 10;
  var newGsSize = $(window).height();
  var newCsWidth = 0.208 * $(window).width();
  var newCsHeight = $(window).height();
  var newCsDispWidth = 0.208 * $(window).width();
  var newCsDispHeight = $(window).height();

  if (window.playTrajBoard || window.timestep < window.total_tsteps || window.n_games < window.max_games) {
    if (gsLX + $(window).height() - ssLX >= maxDist) {
      //means we are overlapping
      newGsSize = $(window).height() - (gsLX + $(window).height() - ssLX); // newCsWidth =8*newCsWidth/10
    }

    if ($(window).height() < 500 || gsLX + $(window).height() - ssLX >= maxDist) {
      newCsDispWidth = 0.5 * $(window).width();
      newCsDispHeight = 2 * $(window).height();
    }
  } //WE NEED TO RESIZE GAME SCREEN BASED ON THE DISTANCE FROM GAME SCREEN TO SCORE


  var gs = $('#gameScreen');
  gs.css("width", newGsSize);
  gs.css("height", newGsSize);
  var sd = $('#scoreScreen');
  sd.css("width", newCsWidth);
  sd.css("height", newCsHeight);
  var qs = $('#queryScreen');
  qs.css("width", 0.75 * $(window).width());
  qs.css("height", 1 * $(window).height());
  var bs = $('.displayInsBtn');
  bs.css("width", 0.1 * $(window).width());
  bs.css("height", 0.075 * $(window).height());
  bs.css("font-size", 0.02 * $(window).height());
  bs.css("left", gsLX + newGsSize / 2 - 0.1 * $(window).width() / 2);
  window.gsWidth = newGsSize;
  window.gsHeight = newGsSize;
  window.qdWidth = 0.75 * $(window).width();
  window.qdHeight = 1 * $(window).height();
  scoreDisp.width = newCsDispWidth;
  scoreDisp.height = newCsDispHeight; //

  rects = updateRects(window.gsWidth, window.gsWidth);
  window.nextRect = rects[0];
  window.leftRect = rects[1];
  window.rightRect = rects[2];
  window.sameRect = rects[3];
  window.incRect = rects[4]; // console.log(window.gsWidth);
}); // function resizeend() {
//     if (new Date() - rtime < delta) {
//         setTimeout(resizeend, delta);
//     } else {
//         timeout = false;
//         window.resizing = false;
//     }
// }
// var rtime;
// var timeout = false;
// var delta = 200;

window.addEventListener("resize", function (event) {
  window.resizing = true; // if (timeout === false) {
  //       timeout = true;
  //       setTimeout(resizeend, delta);
  //   }
  // let dw = window.innerWidth/window.canvas.width;
  // let hw = window.innerHeight/window.canvas.height;
  // console.log(dw);
  // console.log(hw);
  // ctx.scale(dw, hw);

  var gsRect = window.canvas.getBoundingClientRect();
  var gsLX = gsRect.left;
  var ssRect = scoreDisp.getBoundingClientRect();
  var ssLX = ssRect.left;
  var maxDist = 10;
  var newGsSize = $(window).height();
  var newCsWidth = 0.208 * $(window).width();
  var newCsHeight = $(window).height();
  var newCsDispWidth = 0.208 * $(window).width();
  var newCsDispHeight = $(window).height(); // let newCsDispWidth = 0.6*$(window).width();
  // let newCsDispHeight = 1.2*$(window).height();

  if (window.playTrajBoard || window.timestep < window.total_tsteps || window.n_games < window.max_games) {
    if (gsLX + $(window).height() - ssLX >= maxDist) {
      //means we are overlapping
      newGsSize = $(window).height() - (gsLX + $(window).height() - ssLX); // newCsWidth =8*newCsWidth/10
    }

    if ($(window).height() < 500 || gsLX + $(window).height() - ssLX >= maxDist) {
      newCsDispWidth = 0.5 * $(window).width();
      newCsDispHeight = 2 * $(window).height();
    } // if (newCsWidth > (0.42)*newGsSize) {
    //   newCsDispWidth = 0.5*$(window).width();
    //   newCsDispHeight = 2*$(window).height();
    // }

  }

  var gs = $('#gameScreen');
  gs.css("width", newGsSize);
  gs.css("height", newGsSize);
  var sd = $('#scoreScreen');
  sd.css("width", newCsWidth);
  sd.css("height", newCsHeight);
  sd.css("left", gsLX + newGsSize + 10);
  var qs = $('#queryScreen');
  qs.css("width", 0.75 * $(window).width());
  qs.css("height", 0.41 * $(window).width());
  var bs = $('.displayInsBtn');
  bs.css("width", 0.1 * $(window).width());
  bs.css("height", 0.075 * $(window).height());
  bs.css("font-size", 0.02 * $(window).height());
  bs.css("left", gsLX + newGsSize / 2 - 0.1 * $(window).width() / 2); // window.gsWidth = $(window).height();
  // window.gsHeight = $(window).height();

  window.gsWidth = newGsSize;
  window.gsHeight = newGsSize;
  window.qdWidth = 0.75 * $(window).width();
  window.qdHeight = 0.41 * $(window).width();
  scoreDisp.width = newCsDispWidth;
  scoreDisp.height = newCsDispHeight; // scoreDisp.width = 0.208*$(window).width();
  // scoreDisp.height = $(window).height()

  rects = updateRects(window.gsWidth, window.gsWidth);
  window.nextRect = rects[0];
  window.leftRect = rects[1];
  window.rightRect = rects[2];
  window.sameRect = rects[3];
  window.incRect = rects[4]; //
  // window.im.w = 750;
  // window.im.h = 450;
  // window.im.x = -75;
  // window.im.y = 50;
}); //set SVG (for curves as an element of the canvas)

window.spawnPoints = [];
window.boardNames = [];
window.instructions = []; // const spawnPoint1 = { x: 0, y: 5 };
// window.spawnPoints.push(spawnPoint1);
// const boardName1 = "player_board_1";
// window.boardNames.push(boardName1);

var spawnPoint2 = {
  x: 0,
  y: 5
};
window.spawnPoints.push(spawnPoint2);
window.spawnPoints.push(spawnPoint2);
var boardName2 = "player_board_1";
window.boardNames.push(boardName2);
window.boardNames.push(boardName2);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_1_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_1_ins.png");
var spawnPoint3 = {
  x: 0,
  y: 8
};
window.spawnPoints.push(spawnPoint3);
window.spawnPoints.push(spawnPoint3);
var boardName3 = "redone_player_board_2";
window.boardNames.push(boardName3);
window.boardNames.push(boardName3);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_2_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_2_ins.png");
var spawnPoint4 = {
  x: 8,
  y: 9
};
window.spawnPoints.push(spawnPoint4);
window.spawnPoints.push(spawnPoint4);
var boardName4 = "redone_player_board_3";
window.boardNames.push(boardName4);
window.boardNames.push(boardName4);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_3_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_3_ins.png");
var spawnPoint5 = {
  x: 9,
  y: 9
};
window.spawnPoints.push(spawnPoint5);
window.spawnPoints.push(spawnPoint5);
var boardName5 = "redone_player_board_4";
window.boardNames.push(boardName5);
window.boardNames.push(boardName5);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_4_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_4_ins.png");
var spawnPoint6 = {
  x: 8,
  y: 9
};
window.spawnPoints.push(spawnPoint6);
window.spawnPoints.push(spawnPoint6);
var boardName6 = "player_board_5";
window.boardNames.push(boardName6);
window.boardNames.push(boardName6);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_5_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_5_ins.png");
var spawnPoint7 = {
  x: 5,
  y: 5
};
window.spawnPoints.push(spawnPoint7);
window.spawnPoints.push(spawnPoint7);
var boardName7 = "player_board_6";
window.boardNames.push(boardName7);
window.boardNames.push(boardName7);
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_6_ins.png");
window.instructions.push("https://raw.githubusercontent.com/Stephanehk/Prefrence_Elicitation_Interface/main/assets/images/board_6_ins.png"); //------------------------------------------------

window.game = null;
window.playTrajBoard = false;
window.finishedTrajBoard = false;
window.n_games = 0;
window.max_games = 12;
window.finished_game = true;
window.total_tsteps = 200;
window.timestep = 0; //NOTE: USE THIS LINK TO VIEW TRAJECTORIES https://codesandbox.io/s/gridworld-dwkdg?file=/src/trajHandler.js

window.disTraj = false;
window.im = new _instructionsManager.default();
window.qm = new _queryManager.default(); // window.im.createButton(canvas, ctx);
//creates buttons

window.rects = updateRects(window.canvas.width, window.canvas.height);
window.nextRect = rects[0];
window.leftRect = rects[1];
window.rightRect = rects[2];
window.sameRect = rects[3];
window.incRect = rects[4]; //------------------------------------------------
//https://stackoverflow.com/questions/24384368/simple-button-in-html5-canvas/24384882

function getMousePos(canvas, event) {
  var rect = canvas.getBoundingClientRect();
  return {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top
  };
}

function isInside(pos, rect) {
  return pos.x > rect.x && pos.x < rect.x + rect.width && pos.y < rect.y + rect.height && pos.y > rect.y;
}

function updateRects(w, h) {
  var nextRect = {
    x: 0.833 * w,
    y: 0.916 * w,
    width: 100,
    height: 50
  }; // this.offset = 500
  // this.b1_x = 200+(420/2)-(70/2)-100-125
  // this.b1_y = 500-100+15
  // this.b1_h = 50
  // this.b1_w = 70
  // this.b2_x = 290+(420/2)-(70/2)-100+this.offset-125
  // this.b3_x = 720-160/2-100-125
  // this.b3_y = 425-100+15
  // this.b3_h = 130
  // this.b3_w = 50
  // this.b4_y = 500-100+15

  var leftRect = {
    x: window.qm.b1_x / 1009 * window.qdWidth,
    y: window.qm.b1_y / 699 * window.qdHeight,
    width: 50,
    height: 70
  };
  var rightRect = {
    x: window.qm.b2_x / 1009 * window.qdWidth,
    y: window.qm.b1_y / 699 * window.qdHeight,
    width: 50,
    height: 70
  };
  var sameRect = {
    x: window.qm.b3_x / 1009 * window.qdWidth,
    y: window.qm.b3_y / 699 * window.qdHeight,
    width: 130,
    height: 50
  };
  var incRect = {
    x: window.qm.b3_x / 1009 * window.qdWidth,
    y: window.qm.b4_y / 699 * window.qdHeight,
    width: 130,
    height: 50
  };
  return [nextRect, leftRect, rightRect, sameRect, incRect];
} //Binding the click event on the canvas


window.canvas.addEventListener("click", function (evt) {
  var mousePos = getMousePos(window.canvas, evt);

  if (isInside(mousePos, window.nextRect) && !this.finishedIns) {
    window.im.insScene += 1;
  }
}, false);
queryDisp.addEventListener("click", function (evt) {
  var mousePos = getMousePos(queryDisp, evt);

  if (isInside(mousePos, window.leftRect) && window.begunQueries) {
    window.qm.pressed = true;
    window.qm.queried("left");
  } else if (isInside(mousePos, window.rightRect) && window.begunQueries) {
    window.qm.pressed = true;
    window.qm.queried("right");
  } else if (isInside(mousePos, window.sameRect) && window.begunQueries) {
    window.qm.pressed = true;
    window.qm.queried("same");
  } else if (isInside(mousePos, window.incRect) && window.begunQueries) {
    window.qm.pressed = true;
    window.qm.queried("dis");
  }
}, false); //------------------------------------------------

function checkInsCompletion() {
  //check objective and see if we still need to play another board
  if (window.n_games === 1) {
    if (window.game.hitFlag) window.n_games += 1;
  } else if (window.n_games === 3) {
    if (window.game.triedLeaving) window.n_games += 1;
  } else if (window.n_games === 5) {
    if (window.game.hitFlag) window.n_games += 1;
  } else if (window.n_games === 7) {
    if (window.game.hitFlag) window.n_games += 1;
  } else if (window.n_games === 9) {
    if (window.game.hitEdge && window.game.hitHouse) window.n_games += 1;
  } // else if (window.n_games === 11){
  //   if (window.game.hitPerson)window.n_games += 1;
  // }

}

function startNewGame() {
  if (window.finished_game && (window.timestep < window.total_tsteps && window.n_games < window.max_games || window.playTrajBoard)) {
    window.finished_game = false;
    var boardName;
    var spawnPoint;
    var ins = "";
    var dispIns = true;

    if (window.disTraj) {
      boardName = "test_single_goal_mud";
      spawnPoint = {
        x: 0,
        y: 0
      };
    } else if (window.playTrajBoard) {
      boardName = "test_single_goal_mud";
      spawnPoint = {
        x: 0,
        y: 0
      };
      dispIns = false;
    } else {
      boardName = window.boardNames[window.n_games];
      spawnPoint = window.spawnPoints[window.n_games];
      ins = window.instructions[window.n_games];
    } // if (window.n_games===window.max_games) {
    //   //play the trajectory board
    // }


    window.game = new _game.default(GAME_WIDTH, GAME_HEIGHT, spawnPoint, boardName, window.disTraj);
    window.game.start(ins = ins, dispIns = dispIns);
    window.score = new _score.default(window.game);
    window.score.start();
    window.lastTime = 0;
    window.alpha = 1; /// current alpha value

    window.delta = 0.005; /// delta = speed

    window.n_games += 1;
    window.begunQueries = false;
    ctx.globalAlpha = 1; // if (window.n_games === window.max_games) {
    //   return;
    // }
  }
}

function gameLoop(timestamp) {
  ctx.clearRect(0, 0, window.canvas.width, window.canvas.height);
  ctxScore.clearRect(0, 0, scoreDisp.width, scoreDisp.height);
  ctxQuery.clearRect(0, 0, queryDisp.width, queryDisp.height);
  var deltaTime = timestamp - window.lastTime;

  if (!window.im.finishedIns && !window.disTraj) {
    ctx.globalAlpha = 1;
    window.im.update();
    window.im.draw(ctx);
    requestAnimationFrame(gameLoop); // requestAnimationFrame(gameLoop);
  } else if (window.begunQueries) {
    ctx.globalAlpha = 1;
    window.qm.update(deltaTime);
    window.qm.draw(ctxQuery);
    requestAnimationFrame(gameLoop);
  } else {
    startNewGame();
    window.lastTime = timestamp;

    if (window.game.reached_terminal === true && !window.disTraj) {
      //figure out how to fade
      window.alpha -= window.delta; // if (alpha <= 0 || alpha >= 1) delta = -delta;

      ctx.globalAlpha = window.alpha; //clear a bunch of stuff like incompleteCords here
      //if user was playing game
    }

    if (window.alpha > 0) {
      if (window.game.gameObjects != null) {
        window.game.update(deltaTime);
        window.game.draw(ctx);
        window.score.update(deltaTime);
        window.score.draw(ctxScore);

        if (!window.playTrajBoard && (window.timestep > window.total_tsteps || window.n_games >= window.max_games)) {
          window.game.reached_terminal = true;
          window.im.finishedIns = false;
          window.im.finishedGamePlay = true;
          window.finished_game = true;
          $(".displayInsBtn").hide();
        }
      }
    } else {
      window.finished_game = true;
      checkInsCompletion();

      if (window.playTrajBoard) {
        window.playTrajBoard = false;
        window.im.finishedIns = false;
        window.im.finishedGamePlay = true;
        window.finishedTrajBoard = true;
      } // window.playTrajBoard = false;

    }

    requestAnimationFrame(gameLoop);
  }
}

requestAnimationFrame(gameLoop);
},{"regenerator-runtime/runtime":"node_modules/regenerator-runtime/runtime.js","/src/game":"src/game.js","/src/score":"src/score.js","/src/instructionsManager":"src/instructionsManager.js","/src/queryManager":"src/queryManager.js"}],"node_modules/parcel-bundler/src/builtins/hmr-runtime.js":[function(require,module,exports) {
var global = arguments[3];
var OVERLAY_ID = '__parcel__error__overlay__';
var OldModule = module.bundle.Module;

function Module(moduleName) {
  OldModule.call(this, moduleName);
  this.hot = {
    data: module.bundle.hotData,
    _acceptCallbacks: [],
    _disposeCallbacks: [],
    accept: function (fn) {
      this._acceptCallbacks.push(fn || function () {});
    },
    dispose: function (fn) {
      this._disposeCallbacks.push(fn);
    }
  };
  module.bundle.hotData = null;
}

module.bundle.Module = Module;
var checkedAssets, assetsToAccept;
var parent = module.bundle.parent;

if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== 'undefined') {
  var hostname = "" || location.hostname;
  var protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = new WebSocket(protocol + '://' + hostname + ':' + "49445" + '/');

  ws.onmessage = function (event) {
    checkedAssets = {};
    assetsToAccept = [];
    var data = JSON.parse(event.data);

    if (data.type === 'update') {
      var handled = false;
      data.assets.forEach(function (asset) {
        if (!asset.isNew) {
          var didAccept = hmrAcceptCheck(global.parcelRequire, asset.id);

          if (didAccept) {
            handled = true;
          }
        }
      }); // Enable HMR for CSS by default.

      handled = handled || data.assets.every(function (asset) {
        return asset.type === 'css' && asset.generated.js;
      });

      if (handled) {
        console.clear();
        data.assets.forEach(function (asset) {
          hmrApply(global.parcelRequire, asset);
        });
        assetsToAccept.forEach(function (v) {
          hmrAcceptRun(v[0], v[1]);
        });
      } else if (location.reload) {
        // `location` global exists in a web worker context but lacks `.reload()` function.
        location.reload();
      }
    }

    if (data.type === 'reload') {
      ws.close();

      ws.onclose = function () {
        location.reload();
      };
    }

    if (data.type === 'error-resolved') {
      console.log('[parcel] ✨ Error resolved');
      removeErrorOverlay();
    }

    if (data.type === 'error') {
      console.error('[parcel] 🚨  ' + data.error.message + '\n' + data.error.stack);
      removeErrorOverlay();
      var overlay = createErrorOverlay(data);
      document.body.appendChild(overlay);
    }
  };
}

function removeErrorOverlay() {
  var overlay = document.getElementById(OVERLAY_ID);

  if (overlay) {
    overlay.remove();
  }
}

function createErrorOverlay(data) {
  var overlay = document.createElement('div');
  overlay.id = OVERLAY_ID; // html encode message and stack trace

  var message = document.createElement('div');
  var stackTrace = document.createElement('pre');
  message.innerText = data.error.message;
  stackTrace.innerText = data.error.stack;
  overlay.innerHTML = '<div style="background: black; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; opacity: 0.85; font-family: Menlo, Consolas, monospace; z-index: 9999;">' + '<span style="background: red; padding: 2px 4px; border-radius: 2px;">ERROR</span>' + '<span style="top: 2px; margin-left: 5px; position: relative;">🚨</span>' + '<div style="font-size: 18px; font-weight: bold; margin-top: 20px;">' + message.innerHTML + '</div>' + '<pre>' + stackTrace.innerHTML + '</pre>' + '</div>';
  return overlay;
}

function getParents(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return [];
  }

  var parents = [];
  var k, d, dep;

  for (k in modules) {
    for (d in modules[k][1]) {
      dep = modules[k][1][d];

      if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) {
        parents.push(k);
      }
    }
  }

  if (bundle.parent) {
    parents = parents.concat(getParents(bundle.parent, id));
  }

  return parents;
}

function hmrApply(bundle, asset) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (modules[asset.id] || !bundle.parent) {
    var fn = new Function('require', 'module', 'exports', asset.generated.js);
    asset.isNew = !modules[asset.id];
    modules[asset.id] = [fn, asset.deps];
  } else if (bundle.parent) {
    hmrApply(bundle.parent, asset);
  }
}

function hmrAcceptCheck(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (!modules[id] && bundle.parent) {
    return hmrAcceptCheck(bundle.parent, id);
  }

  if (checkedAssets[id]) {
    return;
  }

  checkedAssets[id] = true;
  var cached = bundle.cache[id];
  assetsToAccept.push([bundle, id]);

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    return true;
  }

  return getParents(global.parcelRequire, id).some(function (id) {
    return hmrAcceptCheck(global.parcelRequire, id);
  });
}

function hmrAcceptRun(bundle, id) {
  var cached = bundle.cache[id];
  bundle.hotData = {};

  if (cached) {
    cached.hot.data = bundle.hotData;
  }

  if (cached && cached.hot && cached.hot._disposeCallbacks.length) {
    cached.hot._disposeCallbacks.forEach(function (cb) {
      cb(bundle.hotData);
    });
  }

  delete bundle.cache[id];
  bundle(id);
  cached = bundle.cache[id];

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    cached.hot._acceptCallbacks.forEach(function (cb) {
      cb();
    });

    return true;
  }
}
},{}]},{},["node_modules/parcel-bundler/src/builtins/hmr-runtime.js","src/index.js"], null)
//# sourceMappingURL=/src.a2b27638.js.map